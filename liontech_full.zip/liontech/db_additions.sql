-- ============================================================
--  db_additions.sql — LionTech Business Manager
--  Run AFTER db_structure.sql
--  Adds: subscriptions, payments, activity_logs tables
--  + sample data for 4 demo businesses
-- ============================================================

USE `liontech_db`;

-- ── Add city column to businesses if not present ──────────────
ALTER TABLE `businesses`
  ADD COLUMN IF NOT EXISTS `city` VARCHAR(100) DEFAULT NULL AFTER `address`;

-- ── Add status/disabled column if not present ─────────────────
ALTER TABLE `businesses`
  ADD COLUMN IF NOT EXISTS `disabled` TINYINT(1) NOT NULL DEFAULT 0 AFTER `city`;

-- ──────────────────────────────────────────────────────────────
-- Table: subscriptions
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `subscription_id`   INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `business_id`       INT UNSIGNED     NOT NULL,
  `plan_name`         VARCHAR(100)     NOT NULL DEFAULT 'Standard',
  `amount`            DECIMAL(12,2)    NOT NULL DEFAULT 10000.00,
  `currency`          VARCHAR(10)      NOT NULL DEFAULT 'XAF',
  `start_date`        DATE             NOT NULL,
  `end_date`          DATE             NOT NULL,
  `status`            ENUM('trial','active','expired','cancelled') NOT NULL DEFAULT 'trial',
  `renewed_by`        INT UNSIGNED     DEFAULT NULL,
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`subscription_id`),
  KEY `idx_business_id` (`business_id`),
  KEY `idx_status`      (`status`),
  KEY `idx_end_date`    (`end_date`),
  CONSTRAINT `fk_subs_business`
    FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ──────────────────────────────────────────────────────────────
-- Table: payments
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id`        INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `business_id`       INT UNSIGNED     NOT NULL,
  `subscription_id`   INT UNSIGNED     DEFAULT NULL,
  `amount`            DECIMAL(12,2)    NOT NULL,
  `currency`          VARCHAR(10)      NOT NULL DEFAULT 'XAF',
  `method`            ENUM('mtn_momo','orange_money','bank_transfer','cash') NOT NULL,
  `status`            ENUM('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
  `reference`         VARCHAR(100)     DEFAULT NULL,
  `notes`             TEXT             DEFAULT NULL,
  `paid_at`           DATETIME         DEFAULT NULL,
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `idx_business_id`    (`business_id`),
  KEY `idx_subscription_id`(`subscription_id`),
  KEY `idx_status`         (`status`),
  KEY `idx_paid_at`        (`paid_at`),
  CONSTRAINT `fk_pay_business`
    FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_pay_subscription`
    FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`subscription_id`)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ──────────────────────────────────────────────────────────────
-- Table: activity_logs
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `log_id`       INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`      INT UNSIGNED  DEFAULT NULL,
  `business_id`  INT UNSIGNED  DEFAULT NULL,
  `action`       VARCHAR(100)  NOT NULL,
  `description`  TEXT          DEFAULT NULL,
  `icon`         VARCHAR(50)   DEFAULT 'info',
  `ip_address`   VARCHAR(45)   DEFAULT NULL,
  `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_user_id`    (`user_id`),
  KEY `idx_business_id`(`business_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_action`     (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ──────────────────────────────────────────────────────────────
-- Demo businesses (business_id 3-6)
-- ──────────────────────────────────────────────────────────────
INSERT INTO `businesses`
  (`business_name`, `business_type`, `phone`, `email`, `city`, `subscription_status`, `subscription_expires_at`)
VALUES
  ('Simba Restaurant', 'Restaurant', '+237 670 001 001', 'simba@demo.com',  'Douala',     'active',  DATE_ADD(NOW(), INTERVAL 25 DAY)),
  ('Nora Beauty Salon','Salon',      '+237 670 002 002', 'nora@demo.com',   'Yaoundé',    'active',  DATE_ADD(NOW(), INTERVAL 12 DAY)),
  ('Grace Boutique',   'Boutique',   '+237 670 003 003', 'grace@demo.com',  'Douala',     'expired', DATE_SUB(NOW(), INTERVAL 8 DAY)),
  ('City Snack Bar',   'Snack Bar',  '+237 670 004 004', 'citysnack@demo.com','Bafoussam','trial',   DATE_ADD(NOW(), INTERVAL 7 DAY));

-- ──────────────────────────────────────────────────────────────
-- Demo business owners for businesses 3-6
-- Passwords: Owner@123  (same bcrypt hash as Beta Boutique owner)
-- ──────────────────────────────────────────────────────────────
INSERT INTO `users`
  (`business_id`, `full_name`, `login_id`, `email`, `phone`, `password_hash`, `role`, `status`)
VALUES
  (3, 'John Banda',  'john.banda',  'john@simba.com',   '+237 670 001 001', '$2y$12$0hUj1v7F2WOh1v7F2WOhYOsKqDxs5Y7v3a2bZ8xM1P9tR5kL3mNqi', 'business_owner', 'active'),
  (4, 'Nora Mbeki',  'nora.mbeki',  'nora@salon.com',   '+237 670 002 002', '$2y$12$0hUj1v7F2WOh1v7F2WOhYOsKqDxs5Y7v3a2bZ8xM1P9tR5kL3mNqi', 'business_owner', 'active'),
  (5, 'Grace Tabi',  'grace.tabi',  'grace@boutique.com','+237 670 003 003','$2y$12$0hUj1v7F2WOh1v7F2WOhYOsKqDxs5Y7v3a2bZ8xM1P9tR5kL3mNqi', 'business_owner', 'active'),
  (6, 'Paul Etoa',   'paul.etoa',   'paul@citysnack.com','+237 670 004 004','$2y$12$0hUj1v7F2WOh1v7F2WOhYOsKqDxs5Y7v3a2bZ8xM1P9tR5kL3mNqi', 'business_owner', 'active');

-- ──────────────────────────────────────────────────────────────
-- Subscriptions
-- ──────────────────────────────────────────────────────────────
INSERT INTO `subscriptions`
  (`business_id`, `plan_name`, `amount`, `start_date`, `end_date`, `status`)
VALUES
  (1, 'Standard', 10000, DATE_SUB(CURDATE(), INTERVAL 60 DAY),  DATE_ADD(CURDATE(), INTERVAL 60 DAY),  'active'),
  (2, 'Standard', 10000, DATE_SUB(CURDATE(), INTERVAL 25 DAY),  DATE_SUB(CURDATE(), INTERVAL 5 DAY),   'expired'),
  (3, 'Standard', 10000, DATE_SUB(CURDATE(), INTERVAL 5 DAY),   DATE_ADD(CURDATE(), INTERVAL 25 DAY),  'active'),
  (4, 'Standard', 10000, DATE_SUB(CURDATE(), INTERVAL 18 DAY),  DATE_ADD(CURDATE(), INTERVAL 12 DAY),  'active'),
  (5, 'Standard', 10000, DATE_SUB(CURDATE(), INTERVAL 38 DAY),  DATE_SUB(CURDATE(), INTERVAL 8 DAY),   'expired'),
  (6, 'Trial',    0,     CURDATE(),                              DATE_ADD(CURDATE(), INTERVAL 7 DAY),   'trial');

-- ──────────────────────────────────────────────────────────────
-- Payments
-- ──────────────────────────────────────────────────────────────
INSERT INTO `payments`
  (`business_id`, `subscription_id`, `amount`, `method`, `status`, `reference`, `paid_at`)
VALUES
  (1, 1, 10000, 'mtn_momo',       'completed', 'MMX20250101', DATE_SUB(NOW(), INTERVAL 60 DAY)),
  (3, 3, 10000, 'orange_money',   'completed', 'OM20250115',  DATE_SUB(NOW(), INTERVAL 5 DAY)),
  (4, 4, 10000, 'bank_transfer',  'completed', 'BK20250108',  DATE_SUB(NOW(), INTERVAL 18 DAY)),
  (5, 5, 10000, 'cash',           'completed', 'CSH20241201', DATE_SUB(NOW(), INTERVAL 38 DAY)),
  (6, 6, 10000, 'mtn_momo',       'pending',    NULL,          NULL),
  (2, 2, 10000, 'orange_money',   'pending',    NULL,          NULL);

-- ──────────────────────────────────────────────────────────────
-- Activity logs (sample)
-- ──────────────────────────────────────────────────────────────
INSERT INTO `activity_logs`
  (`user_id`, `business_id`, `action`, `description`, `icon`)
VALUES
  (1, 3, 'business_created',     'New business "Simba Restaurant" created',              'building'),
  (1, 4, 'subscription_activated','Subscription activated for "Nora Beauty Salon"',      'check-circle'),
  (1, 3, 'user_added',           'New employee added to Simba Restaurant',               'user-plus'),
  (1, 3, 'payment_received',     'Payment of 10,000 XAF received from Simba Restaurant','credit-card'),
  (1, 5, 'subscription_expired', 'Subscription expired for Grace Boutique',              'alert-triangle'),
  (1, 1, 'business_login',       'Business owner Alice Mobutu logged in',                'log-in'),
  (1, 6, 'business_created',     'New business "City Snack Bar" added on trial',         'building'),
  (1, NULL,'admin_login',        'Super admin logged in from 197.xxx.xxx.xxx',           'shield');

-- ──────────────────────────────────────────────────────────────
-- Monthly summary view (useful for chart queries)
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW `v_monthly_revenue` AS
SELECT
  DATE_FORMAT(paid_at, '%Y-%m') AS month,
  SUM(amount) AS total_revenue,
  COUNT(*) AS payment_count
FROM payments
WHERE status = 'completed'
  AND paid_at IS NOT NULL
GROUP BY DATE_FORMAT(paid_at, '%Y-%m')
ORDER BY month ASC;

CREATE OR REPLACE VIEW `v_monthly_businesses` AS
SELECT
  DATE_FORMAT(created_at, '%Y-%m') AS month,
  COUNT(*) AS new_businesses
FROM businesses
GROUP BY DATE_FORMAT(created_at, '%Y-%m')
ORDER BY month ASC;

-- ──────────────────────────────────────────────────────────────
-- Quick reference — demo credentials (all roles)
-- ──────────────────────────────────────────────────────────────
-- Super Admin  | admin@liontech.com  | Admin@123
-- Simba owner  | john.banda          | Owner@123
-- Nora owner   | nora.mbeki          | Owner@123
-- Grace owner  | grace.tabi          | Owner@123
-- City Snack   | paul.etoa           | Owner@123
-- ──────────────────────────────────────────────────────────────
