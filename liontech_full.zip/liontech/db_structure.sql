-- ============================================================
--  db_structure.sql — LionTech Business Manager
--  Run this file once to create your database and tables.
--  Compatible with MySQL 8.0+ / MariaDB 10.4+
-- ============================================================

CREATE DATABASE IF NOT EXISTS `liontech_db`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `liontech_db`;

-- ------------------------------------------------------------
-- Table: businesses
-- One row per registered business
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `businesses` (
  `business_id`       INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `business_name`     VARCHAR(255)     NOT NULL,
  `business_type`     VARCHAR(100)     DEFAULT NULL,
  `address`           TEXT             DEFAULT NULL,
  `phone`             VARCHAR(30)      DEFAULT NULL,
  `email`             VARCHAR(255)     DEFAULT NULL,
  `logo_url`          VARCHAR(500)     DEFAULT NULL,
  `subscription_status` ENUM('trial','active','expired','suspended') NOT NULL DEFAULT 'trial',
  `subscription_expires_at` DATETIME   DEFAULT NULL,
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`business_id`),
  UNIQUE KEY `uq_business_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: users
-- All user types share this table (role differentiates them)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `user_id`           INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `business_id`       INT UNSIGNED     DEFAULT NULL,          -- NULL for super_admin
  `full_name`         VARCHAR(255)     NOT NULL,
  `login_id`          VARCHAR(100)     NOT NULL,              -- email / phone / username / employee code
  `email`             VARCHAR(255)     DEFAULT NULL,
  `phone`             VARCHAR(30)      DEFAULT NULL,
  `password_hash`     VARCHAR(255)     NOT NULL,              -- bcrypt
  `role`              ENUM('super_admin','business_owner','manager','employee') NOT NULL,
  `status`            ENUM('active','inactive','suspended')   NOT NULL DEFAULT 'active',
  `last_login`        DATETIME         DEFAULT NULL,
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_login_id` (`login_id`),
  KEY `idx_business_id` (`business_id`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_users_business`
    FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: login_attempts  (brute-force protection)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `login_id`    VARCHAR(100) NOT NULL,
  `ip_address`  VARCHAR(45)  NOT NULL,
  `attempted_at`DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_login_id_time` (`login_id`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: sessions  (optional server-side session log)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `session_id`  VARCHAR(128) NOT NULL,
  `user_id`     INT UNSIGNED NOT NULL,
  `ip_address`  VARCHAR(45)  NOT NULL,
  `user_agent`  VARCHAR(500) DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: products / inventory (stub — expand as needed)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `product_id`  INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `business_id` INT UNSIGNED NOT NULL,
  `name`        VARCHAR(255) NOT NULL,
  `sku`         VARCHAR(100) DEFAULT NULL,
  `quantity`    INT          NOT NULL DEFAULT 0,
  `unit_price`  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `category`    VARCHAR(100) DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`),
  KEY `idx_business_id` (`business_id`),
  CONSTRAINT `fk_products_business`
    FOREIGN KEY (`business_id`) REFERENCES `businesses` (`business_id`)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: attendance (stub)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attendance` (
  `attendance_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED NOT NULL,
  `business_id`   INT UNSIGNED NOT NULL,
  `clock_in`      DATETIME     DEFAULT NULL,
  `clock_out`     DATETIME     DEFAULT NULL,
  `date`          DATE         NOT NULL,
  PRIMARY KEY (`attendance_id`),
  KEY `idx_user_date` (`user_id`, `date`),
  KEY `idx_business_date` (`business_id`, `date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  DEMO DATA
--  Passwords below are bcrypt hashes of the literal strings:
--    Admin@123  /  Owner@123  /  Mgr@123  /  Emp@1234
--  Generated with: password_hash('...', PASSWORD_BCRYPT)
-- ============================================================

-- Demo business
INSERT INTO `businesses`
  (`business_name`, `business_type`, `phone`, `email`, `subscription_status`, `subscription_expires_at`)
VALUES
  ('Acme Store',   'Retail',        '+1 555 100 0001', 'acme@demo.com',   'active',  DATE_ADD(NOW(), INTERVAL 60 DAY)),
  ('Beta Boutique','Fashion',       '+1 555 100 0002', 'beta@demo.com',   'expired', DATE_SUB(NOW(), INTERVAL 5 DAY));

-- Demo users  (password hashes — bcrypt cost 12)
INSERT INTO `users`
  (`business_id`, `full_name`, `login_id`, `email`, `phone`, `password_hash`, `role`, `status`)
VALUES
  -- Super Admin (no business)
  (NULL, 'LionTech Admin',  'admin@liontech.com', 'admin@liontech.com',  NULL,           '$2y$12$KIXmS/sLSQrFZa2fxLzFMuXNBfT1V08N1OdxCJbz1v3Vb2EqK3sMi', 'super_admin',    'active'),

  -- Business Owner — Acme Store (business_id=1)
  (1,    'Alice Mobutu',    '675100001',          'alice@acme.com',       '+1 675 100 001','$2y$12$0hUj1v7F2WOh1v7F2WOhYOsKqDxs5Y7v3a2bZ8xM1P9tR5kL3mNqi', 'business_owner', 'active'),

  -- Solo owner — Beta Boutique (subscription expired, business_id=2)
  (2,    'Bernard Solo',    'bernard@beta.com',   'bernard@beta.com',     '+1 675 100 002','$2y$12$0hUj1v7F2WOh1v7F2WOhYOsKqDxs5Y7v3a2bZ8xM1P9tR5kL3mNqi', 'business_owner', 'active'),

  -- Manager — Acme Store
  (1,    'Marie Manager',   'manager@acme.com',   'manager@acme.com',     NULL,           '$2y$12$xCxSmxJUy3fZ9GxSmxJUyOu8KNzT4G6w1c3eA7yO2Q8vS4jK1nPwi', 'manager',        'active'),

  -- Employee — Acme Store (login via employee code)
  (1,    'Emmanuel Emp',    'EMP001',              NULL,                   NULL,           '$2y$12$mLnVoP5Q2rYt6KnVoP5Q2OzE1DFuA8B3d4fC9pH0R6sN7wI2kOvmi', 'employee',       'active'),

  -- Inactive user example
  (1,    'Old Worker',      'EMP099',              NULL,                   NULL,           '$2y$12$mLnVoP5Q2rYt6KnVoP5Q2OzE1DFuA8B3d4fC9pH0R6sN7wI2kOvmi', 'employee',       'inactive');

-- ============================================================
-- Quick reference — demo credentials
-- ============================================================
-- Role            | Login ID              | Password
-- ----------------+-----------------------+-----------
-- Super Admin     | admin@liontech.com    | Admin@123
-- Business Owner  | 675100001             | Owner@123
-- Expired Owner   | bernard@beta.com      | Owner@123
-- Manager         | manager@acme.com      | Mgr@123
-- Employee        | EMP001                | Emp@1234
-- Inactive        | EMP099                | Emp@1234
-- ============================================================
