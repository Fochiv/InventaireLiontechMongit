<?php
/* ============================================================
   login.php — LionTech Business Manager
   Main login page (entry point)
   ============================================================ */
require_once __DIR__ . '/config.php';
startSecureSession();

/* Redirect already-logged-in users to their dashboard */
if (isLoggedIn()) {
    $routes = json_decode(DASHBOARD_ROUTES, true);
    $dest   = APP_URL . '/' . ($routes[$_SESSION['role']] ?? 'dashboard/owner.php');
    header('Location: ' . $dest);
    exit;
}

/* Optional: surface a query-string error on the form */
$queryError = htmlspecialchars($_GET['error'] ?? '', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="description" content="LionTech Business Manager — secure login for all user types."/>
  <meta name="theme-color" content="#0B1F3A"/>
  <title>Login — LionTech Business Manager</title>

  <!-- Favicon (replace with real icon) -->
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%230B1F3A'/><text y='22' x='5' font-size='20'>🦁</text></svg>"/>

  <!-- Stylesheet -->
  <link rel="stylesheet" href="style.css"/>
</head>
<body>

<!-- ══════════════════════════════════════════════
     PAGE WRAPPER
     ══════════════════════════════════════════════ -->
<div class="lt-page">

  <!-- ── LEFT PANEL ── -->
  <aside class="lt-left" aria-hidden="true">
    <div class="lt-left-bg"></div>
    <div class="lt-blob lt-blob-1"></div>
    <div class="lt-blob lt-blob-2"></div>
    <div class="lt-blob lt-blob-3"></div>

    <!-- Logo -->
    <div class="lt-logo">
      <div class="lt-logo-icon" role="img" aria-label="LionTech logo">🦁</div>
      <div class="lt-logo-text">
        <div class="lt-logo-name">LionTech</div>
        <div class="lt-logo-tag">Business Manager</div>
      </div>
    </div>

    <!-- Heading -->
    <h1 class="lt-left-title">
      <span data-lt="welcome">Welcome to <span>LionTech Business Manager</span></span>
    </h1>
    <p class="lt-left-sub" data-lt="welcome_sub">
      The all-in-one platform designed for African businesses of every size.
    </p>

    <!-- Features -->
    <ul class="lt-features" role="list">
      <li class="lt-feature">
        <div class="lt-feat-icon" aria-hidden="true">📦</div>
        <span class="lt-feat-text" data-lt="feat1">Real-time inventory tracking</span>
      </li>
      <li class="lt-feature">
        <div class="lt-feat-icon" aria-hidden="true">👥</div>
        <span class="lt-feat-text" data-lt="feat2">Employee attendance &amp; payroll</span>
      </li>
      <li class="lt-feature">
        <div class="lt-feat-icon" aria-hidden="true">📊</div>
        <span class="lt-feat-text" data-lt="feat3">Detailed business reports</span>
      </li>
      <li class="lt-feature">
        <div class="lt-feat-icon" aria-hidden="true">🏢</div>
        <span class="lt-feat-text" data-lt="feat4">Multi-business &amp; multi-branch support</span>
      </li>
      <li class="lt-feature">
        <div class="lt-feat-icon" aria-hidden="true">🔐</div>
        <span class="lt-feat-text" data-lt="feat5">Role-based secure access</span>
      </li>
    </ul>

    <div class="lt-left-footer">© 2025 LionTech. All rights reserved.</div>
  </aside>

  <!-- ── RIGHT PANEL ── -->
  <main class="lt-right" role="main">

    <!-- Language toggle -->
    <div class="lt-top-bar">
      <button id="lt-lang-btn" class="lt-lang-btn" aria-label="Switch language">EN</button>
    </div>

    <!-- Mobile-only logo (shown on small screens) -->
    <div class="lt-mobile-logo" aria-hidden="true">
      <div class="lt-mobile-logo-icon">🦁</div>
      <div class="lt-mobile-logo-name">LionTech Business Manager</div>
      <div class="lt-mobile-logo-sub" data-lt="app_subtitle">
        Manage your business, inventory, employees, and reports — all in one place.
      </div>
    </div>

    <!-- Login card -->
    <div class="lt-card" role="region" aria-labelledby="lt-card-heading">

      <!-- Card header -->
      <h2 class="lt-card-title" id="lt-card-heading" data-lt="login_title">Sign In to Your Account</h2>
      <p class="lt-card-sub">LionTech Business Manager</p>

      <!-- Server-side error (PHP session error passthrough) -->
      <?php if ($queryError === 'session_expired'): ?>
      <div class="lt-alert warning visible" role="alert">
        <span class="lt-alert-icon">⚡</span>
        <span>Your session expired. Please sign in again.</span>
      </div>
      <?php elseif ($queryError === 'unauthorized'): ?>
      <div class="lt-alert error visible" role="alert">
        <span class="lt-alert-icon">⚠️</span>
        <span>Access denied. You do not have permission to view that page.</span>
      </div>
      <?php endif; ?>

      <!-- JS alert box -->
      <div id="lt-alert" class="lt-alert" role="alert" aria-live="polite"></div>

      <!-- ── LOGIN FORM ── -->
      <form id="lt-form" method="POST" action="auth.php" novalidate autocomplete="on">

        <!-- Login ID -->
        <div class="lt-form-group">
          <label class="lt-label" for="lt-login-id" data-lt="login_id_label">Login ID</label>
          <div class="lt-input-wrap">
            <input
              type="text"
              id="lt-login-id"
              name="login_id"
              class="lt-input"
              data-lt-ph="login_id_ph"
              placeholder="Email, phone number, username, or employee code"
              autocomplete="username"
              autocapitalize="none"
              autocorrect="off"
              spellcheck="false"
              required
              aria-required="true"
            />
          </div>
        </div>

        <!-- Password / PIN -->
        <div class="lt-form-group">
          <label class="lt-label" for="lt-password" data-lt="password_label">Password / PIN</label>
          <div class="lt-input-wrap">
            <input
              type="password"
              id="lt-password"
              name="password"
              class="lt-input has-icon"
              data-lt-ph="password_ph"
              placeholder="Enter your password or PIN"
              autocomplete="current-password"
              required
              aria-required="true"
              inputmode="text"
            />
            <button type="button" id="lt-eye-btn" class="lt-eye-btn" aria-label="Show password">
              <!-- SVG injected by app.js -->
            </button>
          </div>
        </div>

        <!-- Submit -->
        <button type="submit" id="lt-btn-login" class="lt-btn-login" aria-live="polite">
          <div class="lt-spinner" aria-hidden="true"></div>
          <span data-lt="btn_login">Login</span>
        </button>

        <!-- Links -->
        <div class="lt-links">
          <button type="button" class="lt-link" data-lt="forgot"
            onclick="alert('Please contact LionTech support to reset your password.')">
            Forgot password?
          </button>
          <a href="mailto:support@liontech.com" class="lt-link" data-lt="support">
            Contact LionTech for support
          </a>
        </div>

      </form>

      <div class="lt-divider"></div>

      <!-- ── DEMO CREDENTIALS ── -->
      <div class="lt-demo" id="lt-demo">
        <div class="lt-demo-header" id="lt-demo-header" role="button" tabindex="0"
          aria-expanded="false" aria-controls="lt-demo-body">
          <div class="lt-demo-title">
            <span id="lt-demo-title-text">Demo credentials</span>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <span class="lt-demo-hint" id="lt-demo-hint">Click any row to auto-fill</span>
            <span class="lt-demo-chevron">▼</span>
          </div>
        </div>
        <div class="lt-demo-body" id="lt-demo-body">
          <table role="grid" aria-label="Demo login credentials">
            <thead id="lt-demo-thead">
              <tr>
                <th>Role</th><th>Login ID</th><th>Password</th>
              </tr>
            </thead>
            <tbody id="lt-demo-tbody">
              <!-- Populated by app.js -->
            </tbody>
          </table>
        </div>
      </div>

    </div><!-- /.lt-card -->

    <!-- Footer -->
    <div class="lt-right-footer">
      <span data-lt="footer_copy">© 2025 LionTech. All rights reserved.</span>
      <div class="lt-footer-links">
        <a href="#" data-lt="footer_privacy">Privacy Policy</a>
        <a href="#" data-lt="footer_terms">Terms of Service</a>
      </div>
    </div>

  </main><!-- /.lt-right -->

</div><!-- /.lt-page -->

<!-- Scripts -->
<script src="lang.js"></script>
<script src="app.js"></script>

</body>
</html>
