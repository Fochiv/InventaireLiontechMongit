<?php
/* ============================================================
   auth.php — LionTech Business Manager
   Handles POST login, validates credentials, sets session,
   and returns JSON response consumed by login.js
   ============================================================ */

require_once __DIR__ . '/config.php';
startSecureSession();

/* ── Only allow POST ── */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Method not allowed.']));
}

header('Content-Type: application/json');

/* ── Read & sanitize input ── */
$raw       = file_get_contents('php://input');
$data      = json_decode($raw, true) ?: $_POST;
$loginId   = trim($data['login_id']  ?? '');
$password  = trim($data['password']  ?? '');

if ($loginId === '' || $password === '') {
    exit(json_encode(['success' => false, 'message' => 'Please fill in all fields.', 'code' => 'empty_fields']));
}

/* ── Brute-force protection: max 10 attempts per 15 min ── */
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$pdo = getDB();

$stmtAttempts = $pdo->prepare(
    "SELECT COUNT(*) FROM login_attempts
     WHERE login_id = :lid AND ip_address = :ip
     AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)"
);
$stmtAttempts->execute([':lid' => $loginId, ':ip' => $ip]);
$attemptCount = (int) $stmtAttempts->fetchColumn();

if ($attemptCount >= 10) {
    exit(json_encode([
        'success' => false,
        'message' => 'Too many failed attempts. Please wait 15 minutes or contact LionTech support.',
        'code'    => 'too_many_attempts',
    ]));
}

/* ── Look up user by login_id ── */
$stmtUser = $pdo->prepare(
    "SELECT u.*, b.subscription_status, b.subscription_expires_at
     FROM users u
     LEFT JOIN businesses b ON u.business_id = b.business_id
     WHERE u.login_id = :lid
     LIMIT 1"
);
$stmtUser->execute([':lid' => $loginId]);
$user = $stmtUser->fetch();

/* ── Helper: log failed attempt ── */
$logFail = function () use ($pdo, $loginId, $ip) {
    $pdo->prepare("INSERT INTO login_attempts (login_id, ip_address) VALUES (:lid, :ip)")
        ->execute([':lid' => $loginId, ':ip' => $ip]);
};

/* ── User not found ── */
if (!$user) {
    $logFail();
    exit(json_encode(['success' => false, 'message' => 'Invalid login ID or password.', 'code' => 'invalid_credentials']));
}

/* ── Verify password (bcrypt or PIN) ── */
$passwordValid = false;

// Standard bcrypt hash
if (password_verify($password, $user['password_hash'])) {
    $passwordValid = true;
}
// PIN fallback: numeric 4-6 digits stored as bcrypt
// (same verification — bcrypt handles both passwords and PINs)

if (!$passwordValid) {
    $logFail();
    exit(json_encode(['success' => false, 'message' => 'Invalid login ID or password.', 'code' => 'invalid_credentials']));
}

/* ── Account status check ── */
if ($user['status'] === 'inactive' || $user['status'] === 'suspended') {
    exit(json_encode([
        'success' => false,
        'message' => 'Your account is inactive. Please contact LionTech.',
        'code'    => 'account_inactive',
    ]));
}

/* ── Subscription check (owners only) ── */
$subscriptionWarning = null;
if (in_array($user['role'], [ROLE_BUSINESS_OWNER, ROLE_MANAGER, ROLE_EMPLOYEE], true)) {
    if ($user['subscription_status'] === 'expired') {
        if ($user['role'] === ROLE_BUSINESS_OWNER) {
            // Owner must renew — redirect to payment page
            exit(json_encode([
                'success'  => false,
                'message'  => 'Your subscription has expired. Please renew to continue.',
                'code'     => 'subscription_expired',
                'redirect' => APP_URL . '/dashboard/subscription.php',
            ]));
        } else {
            // Manager/Employee cannot log in if business subscription expired
            exit(json_encode([
                'success' => false,
                'message' => 'Your business subscription has expired. Please contact your business owner.',
                'code'    => 'subscription_expired',
            ]));
        }
    }
    // Trial warning
    if ($user['subscription_status'] === 'trial') {
        $subscriptionWarning = 'You are on a trial plan. Upgrade to avoid service interruption.';
    }
}

/* ── Determine dashboard route ── */
$routes = json_decode(DASHBOARD_ROUTES, true);
$redirect = APP_URL . '/' . ($routes[$user['role']] ?? 'dashboard/owner.php');

/* ── Set session ── */
session_regenerate_id(true); // prevent session fixation
$_SESSION['user_id']     = $user['user_id'];
$_SESSION['business_id'] = $user['business_id'];
$_SESSION['full_name']   = $user['full_name'];
$_SESSION['role']        = $user['role'];
$_SESSION['email']       = $user['email'];
$_SESSION['login_time']  = time();

/* ── Update last_login ── */
$pdo->prepare("UPDATE users SET last_login = NOW() WHERE user_id = :uid")
    ->execute([':uid' => $user['user_id']]);

/* ── Clear brute-force log on success ── */
$pdo->prepare("DELETE FROM login_attempts WHERE login_id = :lid AND ip_address = :ip")
    ->execute([':lid' => $loginId, ':ip' => $ip]);

/* ── Success response ── */
exit(json_encode([
    'success'             => true,
    'role'                => $user['role'],
    'full_name'           => $user['full_name'],
    'redirect'            => $redirect,
    'subscription_warning'=> $subscriptionWarning,
    'code'                => 'ok',
]));
