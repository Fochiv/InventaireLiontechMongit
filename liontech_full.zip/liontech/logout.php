<?php
require_once __DIR__ . '/config.php';
logout(); // destroys session and redirects to login.php
