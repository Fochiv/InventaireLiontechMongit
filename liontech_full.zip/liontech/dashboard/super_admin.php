<?php
/* ============================================================
   super_admin.php — LionTech Super Admin Dashboard
   Role: super_admin only. All others → redirect.
   ============================================================ */
require_once __DIR__ . '/../config.php';
requireRole([ROLE_SUPER_ADMIN]);
$user = currentUser();

$pdo = getDB();

/* ── STATS (sample — replace with DB queries) ── */
$stats = ['total'=>6,'active'=>4,'expired'=>2,'users'=>12,'pending'=>2,'activity'=>8];

/* ── BUSINESSES ── */
$businesses = [
  ['id'=>1,'name'=>'Acme Store',       'type'=>'Retail',     'owner'=>'Alice Mobutu','phone'=>'+237 675 100 001','city'=>'Douala',     'status'=>'active',  'created'=>'2025-01-10'],
  ['id'=>2,'name'=>'Beta Boutique',    'type'=>'Fashion',    'owner'=>'Bernard Solo','phone'=>'+237 675 100 002','city'=>'Yaoundé',    'status'=>'expired', 'created'=>'2025-01-12'],
  ['id'=>3,'name'=>'Simba Restaurant', 'type'=>'Restaurant', 'owner'=>'John Banda',  'phone'=>'+237 670 001 001','city'=>'Douala',     'status'=>'active',  'created'=>'2025-01-15'],
  ['id'=>4,'name'=>'Nora Beauty Salon','type'=>'Salon',      'owner'=>'Nora Mbeki',  'phone'=>'+237 670 002 002','city'=>'Yaoundé',    'status'=>'active',  'created'=>'2025-01-18'],
  ['id'=>5,'name'=>'Grace Boutique',   'type'=>'Boutique',   'owner'=>'Grace Tabi',  'phone'=>'+237 670 003 003','city'=>'Douala',     'status'=>'expired', 'created'=>'2024-12-01'],
  ['id'=>6,'name'=>'City Snack Bar',   'type'=>'Snack Bar',  'owner'=>'Paul Etoa',   'phone'=>'+237 670 004 004','city'=>'Bafoussam','status'=>'pending', 'created'=>'2025-01-20'],
];

/* ── SUBSCRIPTION ALERTS ── */
$alerts = [
  ['id'=>5,'name'=>'Grace Boutique',   'type'=>'expired','msg'=>'Expired 8 days ago',             'date'=>date('M d, Y',strtotime('-8 days'))],
  ['id'=>2,'name'=>'Beta Boutique',    'type'=>'expired','msg'=>'Expired 5 days ago',             'date'=>date('M d, Y',strtotime('-5 days'))],
  ['id'=>4,'name'=>'Nora Beauty Salon','type'=>'warning','msg'=>'Subscription ends in 12 days',   'date'=>date('M d, Y',strtotime('+12 days'))],
  ['id'=>6,'name'=>'City Snack Bar',   'type'=>'pending','msg'=>'Payment pending — trial expires','date'=>date('M d, Y',strtotime('+7 days'))],
];

/* ── RECENT ACTIVITY ── */
$activity = [
  ['icon'=>'🏢','color'=>'teal', 'desc'=>'New business "Simba Restaurant" created',          'biz'=>'Simba Restaurant','time'=>'2 hours ago'],
  ['icon'=>'✅','color'=>'green','desc'=>'Subscription activated for Nora Beauty Salon',     'biz'=>'Nora Beauty Salon','time'=>'5 hours ago'],
  ['icon'=>'👤','color'=>'blue', 'desc'=>'New employee added to Acme Store',                 'biz'=>'Acme Store',       'time'=>'1 day ago'],
  ['icon'=>'💳','color'=>'green','desc'=>'Payment of 10,000 XAF received',                  'biz'=>'Simba Restaurant', 'time'=>'1 day ago'],
  ['icon'=>'⚠️','color'=>'red',  'desc'=>'Subscription expired for Grace Boutique',          'biz'=>'Grace Boutique',  'time'=>'3 days ago'],
  ['icon'=>'🔑','color'=>'navy', 'desc'=>'Super admin logged in from 197.xxx.xxx.xxx',       'biz'=>null,               'time'=>'4 hours ago'],
  ['icon'=>'🏢','color'=>'teal', 'desc'=>'New business "City Snack Bar" added on trial',     'biz'=>'City Snack Bar',  'time'=>'4 days ago'],
  ['icon'=>'💳','color'=>'amber','desc'=>'Payment pending for Beta Boutique',                'biz'=>'Beta Boutique',   'time'=>'5 days ago'],
];

/* ── CHART DATA ── */
$chartData = [
  'labels'        => ['Jan','Feb','Mar','Apr','May','Jun'],
  'revenue'       => [45000,80000,65000,120000,95000,110000],
  'subscriptions' => [2,3,4,5,7,8],
];

/* Admin initials */
$initials='';
foreach(explode(' ',$user['full_name']) as $w) $initials.=strtoupper($w[0]??'');
$initials=substr($initials,0,2);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta name="robots" content="noindex,nofollow"/>
<title>Super Admin Dashboard — LionTech</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%230B1F3A'/><text y='22' x='5' font-size='20'>🦁</text></svg>"/>
<link rel="stylesheet" href="super_admin.css"/>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>window.SA_CHART_DATA=<?=json_encode($chartData)?>;</script>
</head>
<body>
<div class="sa-layout">

<!-- ══ SIDEBAR ══ -->
<aside class="sa-sidebar" id="sa-sidebar">
  <div class="sa-sidebar-header">
    <div class="sa-logo">
      <div class="sa-logo-icon">🦁</div>
      <div><div class="sa-logo-name">LionTech</div><div class="sa-logo-tag">Business Manager</div></div>
    </div>
    <button class="sa-sidebar-close" id="sa-sidebar-close">✕</button>
  </div>
  <nav class="sa-nav">
    <div class="sa-nav-section">Main</div>
    <button class="sa-nav-item active" data-page="dashboard"><span class="sa-nav-icon">📊</span><span>Dashboard</span></button>
    <button class="sa-nav-item" data-page="businesses"><span class="sa-nav-icon">🏢</span><span>Businesses</span><span class="sa-nav-badge"><?=$stats['total']?></span></button>
    <button class="sa-nav-item" data-page="add-business" data-open-modal="add-business"><span class="sa-nav-icon">➕</span><span>Add Business</span></button>
    <div class="sa-nav-section">Platform</div>
    <button class="sa-nav-item" data-page="subscriptions"><span class="sa-nav-icon">🔄</span><span>Subscriptions</span><span class="sa-nav-badge"><?=$stats['expired']?></span></button>
    <button class="sa-nav-item" data-page="users"><span class="sa-nav-icon">👥</span><span>Users</span><span class="sa-nav-badge"><?=$stats['users']?></span></button>
    <button class="sa-nav-item" data-page="payments"><span class="sa-nav-icon">💳</span><span>Payments</span><?php if($stats['pending']>0):?><span class="sa-nav-badge"><?=$stats['pending']?></span><?php endif;?></button>
    <button class="sa-nav-item" data-page="reports"><span class="sa-nav-icon">📈</span><span>Reports</span></button>
    <div class="sa-nav-section">System</div>
    <button class="sa-nav-item" data-page="settings"><span class="sa-nav-icon">⚙️</span><span>Settings</span></button>
    <a class="sa-nav-item sa-nav-logout" href="../logout.php"><span class="sa-nav-icon">🚪</span><span>Logout</span></a>
  </nav>
  <div class="sa-sidebar-footer">
    <div class="sa-sidebar-avatar"><?=htmlspecialchars($initials)?></div>
    <div><div class="sa-sidebar-name"><?=htmlspecialchars($user['full_name'])?></div><div class="sa-sidebar-role">Super Admin</div></div>
  </div>
</aside>
<div class="sa-overlay" id="sa-overlay"></div>

<!-- ══ MAIN ══ -->
<div class="sa-main">

<!-- Topbar -->
<header class="sa-topbar">
  <button class="sa-hamburger" id="sa-hamburger">☰</button>
  <div class="sa-topbar-search">
    <span class="sa-search-icon">🔍</span>
    <input type="search" id="topbar-search" placeholder="Search businesses, users…"/>
  </div>
  <div class="sa-topbar-right">
    <div style="position:relative">
      <button class="sa-icon-btn" data-dropdown="notif-dropdown">🔔<span class="sa-notif-dot"></span></button>
      <div class="sa-dropdown sa-notif-panel" id="notif-dropdown">
        <div class="sa-notif-header">Notifications (<?=count($alerts)?>)</div>
        <?php foreach(array_slice($alerts,0,3) as $a):?>
        <div class="sa-notif-item">
          <div class="sa-notif-ico" style="background:<?=$a['type']==='expired'?'#FEF2F2':($a['type']==='warning'?'#FFFBEB':'#EFF6FF')?>"><?=$a['type']==='expired'?'❌':($a['type']==='warning'?'⚠️':'💳')?></div>
          <div><div class="sa-notif-txt"><?=htmlspecialchars($a['msg'])?></div><div class="sa-notif-time"><?=htmlspecialchars($a['name'])?></div></div>
        </div>
        <?php endforeach;?>
      </div>
    </div>
    <div style="position:relative">
      <button class="sa-profile-btn" data-dropdown="profile-dropdown">
        <div class="sa-profile-av"><?=htmlspecialchars($initials)?></div>
        <div><div class="sa-profile-name"><?=htmlspecialchars(explode(' ',$user['full_name'])[0])?></div><div class="sa-profile-role">Super Admin</div></div>
        <span class="sa-chev">▾</span>
      </button>
      <div class="sa-dropdown" id="profile-dropdown">
        <div class="sa-dropdown-item">👤 My Profile</div>
        <div class="sa-dropdown-item">⚙️ Settings</div>
        <div class="sa-dropdown-divider"></div>
        <a class="sa-dropdown-item danger" href="../logout.php">🚪 Logout</a>
      </div>
    </div>
  </div>
</header>

<!-- Content -->
<main class="sa-content">

  <!-- Page Header -->
  <div class="sa-page-header">
    <div><h1 class="sa-page-title">Super Admin Dashboard</h1><p class="sa-page-sub">Manage businesses, subscriptions, users, and platform activity.</p></div>
    <div class="sa-page-actions">
      <button class="sa-btn sa-btn-outline">📈 View Reports</button>
      <button class="sa-btn sa-btn-outline">🔄 Manage Subscriptions</button>
      <button class="sa-btn sa-btn-primary" data-open-modal="add-business">➕ Add New Business</button>
    </div>
  </div>

  <!-- Stat Cards -->
  <div class="sa-cards-grid">
    <div class="sa-stat-card navy"><div class="sa-stat-icon navy">🏢</div><div><div class="sa-stat-val"><?=$stats['total']?></div><div class="sa-stat-label">Total Businesses</div><div class="sa-stat-trend sa-trend-up">↑ +2 this month</div></div></div>
    <div class="sa-stat-card green"><div class="sa-stat-icon green">✅</div><div><div class="sa-stat-val"><?=$stats['active']?></div><div class="sa-stat-label">Active Businesses</div><div class="sa-stat-trend sa-trend-up">↑ 67% active rate</div></div></div>
    <div class="sa-stat-card red"><div class="sa-stat-icon red">⚠️</div><div><div class="sa-stat-val"><?=$stats['expired']?></div><div class="sa-stat-label">Expired Subscriptions</div><div class="sa-stat-trend sa-trend-down">Action needed</div></div></div>
    <div class="sa-stat-card teal"><div class="sa-stat-icon teal">👥</div><div><div class="sa-stat-val"><?=$stats['users']?></div><div class="sa-stat-label">Total Users</div><div class="sa-stat-trend sa-trend-up">↑ +3 this week</div></div></div>
    <div class="sa-stat-card amber"><div class="sa-stat-icon amber">💳</div><div><div class="sa-stat-val"><?=$stats['pending']?></div><div class="sa-stat-label">Pending Payments</div><div class="sa-stat-trend sa-trend-down">20,000 XAF due</div></div></div>
    <div class="sa-stat-card blue"><div class="sa-stat-icon blue">📋</div><div><div class="sa-stat-val"><?=$stats['activity']?></div><div class="sa-stat-label">Today's Activity</div><div class="sa-stat-trend sa-trend-neu">events logged</div></div></div>
  </div>

  <!-- Chart + Alerts -->
  <div class="sa-row">
    <div class="sa-card">
      <div class="sa-card-header">
        <div><div class="sa-card-title">Monthly Trends</div><div class="sa-card-sub">Revenue (XAF) &amp; Active Subscriptions — Jan–Jun 2025</div></div>
        <button class="sa-btn sa-btn-sm sa-btn-outline">Export CSV</button>
      </div>
      <div class="sa-chart-wrap"><canvas id="sa-chart"></canvas></div>
      <div class="sa-chart-legend">
        <div class="sa-legend-item"><div class="sa-legend-dot" style="background:#D4A017"></div>Revenue (XAF)</div>
        <div class="sa-legend-item"><div class="sa-legend-dot" style="background:#1A9E7A"></div>Active Subscriptions</div>
      </div>
    </div>
    <div class="sa-card">
      <div class="sa-card-header">
        <div><div class="sa-card-title">Subscription Alerts</div><div class="sa-card-sub">Businesses needing attention</div></div>
        <span style="background:#FEF2F2;color:#DC2626;font-size:11px;font-weight:700;border-radius:50px;padding:3px 10px"><?=count($alerts)?> alerts</span>
      </div>
      <div class="sa-alerts-list">
        <?php foreach($alerts as $a):?>
        <div class="sa-alert-item <?=htmlspecialchars($a['type'])?>">
          <span class="sa-alert-icon"><?=$a['type']==='expired'?'❌':($a['type']==='warning'?'⚠️':'💳')?></span>
          <div style="flex:1;min-width:0">
            <div class="sa-alert-biz"><?=htmlspecialchars($a['name'])?></div>
            <div class="sa-alert-msg"><?=htmlspecialchars($a['msg'])?></div>
            <div class="sa-alert-date"><?=htmlspecialchars($a['date'])?></div>
          </div>
          <button class="sa-alert-renew" data-id="<?=$a['id']?>" data-name="<?=htmlspecialchars($a['name'])?>">Renew</button>
        </div>
        <?php endforeach;?>
      </div>
    </div>
  </div>

  <!-- Business Table -->
  <div class="sa-card sa-table-card">
    <div class="sa-card-header">
      <div><div class="sa-card-title">Business Overview</div><div class="sa-card-sub" id="table-count">Showing <?=count($businesses)?> businesses</div></div>
      <button class="sa-btn sa-btn-sm sa-btn-primary" data-open-modal="add-business">➕ Add Business</button>
    </div>
    <div class="sa-table-controls">
      <div class="sa-search-wrap">
        <span class="sa-search-ico">🔍</span>
        <input type="search" class="sa-table-search" id="table-search" placeholder="Search by name, type, owner, city…"/>
      </div>
      <select class="sa-table-filter" id="table-filter">
        <option value="all">All Status</option>
        <option value="active">Active</option>
        <option value="expired">Expired</option>
        <option value="pending">Pending</option>
        <option value="trial">Trial</option>
      </select>
      <select class="sa-table-sort">
        <option value="">Sort by…</option>
        <option>Name</option><option>Date</option><option>Status</option>
      </select>
    </div>
    <div class="sa-table-wrap">
      <table class="sa-table" id="businesses-table">
        <thead><tr>
          <th>Business Name</th><th>Type</th><th>Owner</th><th>Phone</th><th>City</th><th>Status</th><th>Created</th><th>Actions</th>
        </tr></thead>
        <tbody>
        <?php foreach($businesses as $b):?>
        <tr data-id="<?=$b['id']?>" data-name="<?=htmlspecialchars($b['name'])?>" data-type="<?=htmlspecialchars($b['type'])?>" data-owner="<?=htmlspecialchars($b['owner'])?>" data-phone="<?=htmlspecialchars($b['phone'])?>" data-city="<?=htmlspecialchars($b['city'])?>" data-status="<?=htmlspecialchars($b['status'])?>" data-date="<?=htmlspecialchars($b['created'])?>">
          <td><?=htmlspecialchars($b['name'])?></td>
          <td><?=htmlspecialchars($b['type'])?></td>
          <td><?=htmlspecialchars($b['owner'])?></td>
          <td><?=htmlspecialchars($b['phone'])?></td>
          <td><?=htmlspecialchars($b['city'])?></td>
          <td><span class="sa-badge sa-badge-<?=htmlspecialchars($b['status'])?>"><?=ucfirst(htmlspecialchars($b['status']))?></span></td>
          <td><?=htmlspecialchars($b['created'])?></td>
          <td>
            <div class="sa-tbl-actions">
              <button class="sa-tbl-btn sa-tbl-btn-view" onclick="viewBusiness(<?=$b['id']?>,'<?=addslashes($b['name'])?>','<?=addslashes($b['type'])?>','<?=addslashes($b['owner'])?>','<?=addslashes($b['phone'])?>','<?=addslashes($b['city'])?>','<?=$b['status']?>','<?=$b['created']?>')">View</button>
              <button class="sa-tbl-btn sa-tbl-btn-edit" onclick="editBusiness(<?=$b['id']?>,'<?=addslashes($b['name'])?>','<?=addslashes($b['type'])?>','<?=addslashes($b['owner'])?>','<?=addslashes($b['phone'])?>','<?=addslashes($b['city'])?>')">Edit</button>
              <button class="sa-tbl-btn sa-tbl-btn-disable" onclick="confirmDisable(<?=$b['id']?>,'<?=addslashes($b['name'])?>')">Disable</button>
              <?php if($b['status']==='expired'||$b['status']==='pending'):?>
              <button class="sa-tbl-btn sa-tbl-btn-renew" onclick="renewSubscription(<?=$b['id']?>,'<?=addslashes($b['name'])?>')">Renew</button>
              <?php endif;?>
            </div>
          </td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
    <div class="sa-pagination"><span>Page 1 of 1</span><div class="sa-pg-btns"><button class="sa-pg-btn">‹</button><button class="sa-pg-btn active">1</button><button class="sa-pg-btn">›</button></div></div>
  </div>

  <!-- Recent Activity -->
  <div class="sa-card">
    <div class="sa-card-header">
      <div><div class="sa-card-title">Recent Activity</div><div class="sa-card-sub">Latest platform events</div></div>
      <button class="sa-btn sa-btn-sm sa-btn-outline">View All Logs</button>
    </div>
    <div class="sa-activity-list">
      <?php foreach($activity as $act):?>
      <div class="sa-activity-item">
        <div class="sa-activity-icon sa-act-<?=htmlspecialchars($act['color'])?>"><?=$act['icon']?></div>
        <div style="flex:1;min-width:0">
          <div class="sa-activity-desc"><?=htmlspecialchars($act['desc'])?></div>
          <?php if($act['biz']):?><div class="sa-activity-biz"><?=htmlspecialchars($act['biz'])?></div><?php endif;?>
          <div class="sa-activity-time"><?=htmlspecialchars($act['time'])?></div>
        </div>
      </div>
      <?php endforeach;?>
    </div>
  </div>

</main>
</div><!-- /.sa-main -->
</div><!-- /.sa-layout -->

<!-- ══ MODALS ══ -->

<!-- View Business -->
<div class="sa-modal-overlay" id="view-business-modal">
  <div class="sa-modal">
    <div class="sa-modal-header"><h2 class="sa-modal-title">Business Details</h2><button class="sa-modal-close" data-close-modal>✕</button></div>
    <div class="sa-modal-body">
      <div class="sa-detail-grid">
        <div class="sa-detail-item"><div class="sa-detail-label">Business Name</div><div class="sa-detail-val" id="view-biz-name">—</div></div>
        <div class="sa-detail-item"><div class="sa-detail-label">Type</div><div class="sa-detail-val" id="view-biz-type">—</div></div>
        <div class="sa-detail-item"><div class="sa-detail-label">Owner</div><div class="sa-detail-val" id="view-biz-owner">—</div></div>
        <div class="sa-detail-item"><div class="sa-detail-label">Phone</div><div class="sa-detail-val" id="view-biz-phone">—</div></div>
        <div class="sa-detail-item"><div class="sa-detail-label">City</div><div class="sa-detail-val" id="view-biz-city">—</div></div>
        <div class="sa-detail-item"><div class="sa-detail-label">Date Created</div><div class="sa-detail-val" id="view-biz-date">—</div></div>
        <div class="sa-detail-item" style="grid-column:1/-1"><div class="sa-detail-label">Status</div><div class="sa-detail-val"><span class="sa-badge" id="view-biz-status">—</span></div></div>
      </div>
    </div>
    <div class="sa-modal-footer"><button class="sa-btn sa-btn-outline" data-close-modal>Close</button><button class="sa-btn sa-btn-primary">Full Profile</button></div>
  </div>
</div>

<!-- Edit Business -->
<div class="sa-modal-overlay" id="edit-business-modal">
  <div class="sa-modal sa-modal-lg">
    <div class="sa-modal-header"><h2 class="sa-modal-title">Edit Business</h2><button class="sa-modal-close" data-close-modal>✕</button></div>
    <div class="sa-modal-body">
      <input type="hidden" id="edit-biz-id"/>
      <div class="sa-form-grid">
        <div class="sa-form-group"><label class="sa-form-label">Business Name *</label><input type="text" class="sa-form-input" id="edit-biz-name"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Type *</label><select class="sa-form-select" id="edit-biz-type"><option>Restaurant</option><option>Salon</option><option>Boutique</option><option>Snack Bar</option><option>Retail</option><option>Fashion</option><option>Other</option></select></div>
        <div class="sa-form-group"><label class="sa-form-label">Owner Name</label><input type="text" class="sa-form-input" id="edit-biz-owner"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Phone</label><input type="tel" class="sa-form-input" id="edit-biz-phone"/></div>
        <div class="sa-form-group"><label class="sa-form-label">City</label><input type="text" class="sa-form-input" id="edit-biz-city"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Status</label><select class="sa-form-select" id="edit-biz-status-sel"><option value="active">Active</option><option value="expired">Expired</option><option value="trial">Trial</option><option value="suspended">Suspended</option></select></div>
      </div>
    </div>
    <div class="sa-modal-footer"><button class="sa-btn sa-btn-outline" data-close-modal>Cancel</button><button class="sa-btn sa-btn-primary" onclick="saveEdit()">Save Changes</button></div>
  </div>
</div>

<!-- Disable Confirm -->
<div class="sa-modal-overlay" id="disable-modal">
  <div class="sa-modal" style="max-width:420px">
    <div class="sa-modal-header"><h2 class="sa-modal-title">Disable Business</h2><button class="sa-modal-close" data-close-modal>✕</button></div>
    <div class="sa-modal-body"><div class="sa-confirm-icon">⛔</div><p class="sa-confirm-msg" id="disable-confirm-msg">Are you sure?</p></div>
    <div class="sa-modal-footer"><button class="sa-btn sa-btn-outline" data-close-modal>Cancel</button><button class="sa-btn sa-btn-danger" id="disable-confirm-btn">Yes, Disable</button></div>
  </div>
</div>

<!-- Renew Subscription -->
<div class="sa-modal-overlay" id="renew-modal">
  <div class="sa-modal">
    <div class="sa-modal-header"><h2 class="sa-modal-title">Renew Subscription</h2><button class="sa-modal-close" data-close-modal>✕</button></div>
    <div class="sa-modal-body">
      <input type="hidden" id="renew-biz-id"/>
      <p style="font-size:13.5px;color:#64748B;margin-bottom:16px">Renewing for: <strong id="renew-biz-name" style="color:#0B1F3A">—</strong></p>
      <div class="sa-form-grid">
        <div class="sa-form-group"><label class="sa-form-label">Plan</label><select class="sa-form-select" id="renew-plan"><option value="standard">Standard — 10,000 XAF/mo</option><option value="premium">Premium — 20,000 XAF/mo</option></select></div>
        <div class="sa-form-group"><label class="sa-form-label">Amount (XAF)</label><input type="number" class="sa-form-input" id="renew-amount" value="10000" min="0"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Start Date</label><input type="date" class="sa-form-input" id="renew-start"/></div>
        <div class="sa-form-group"><label class="sa-form-label">End Date</label><input type="date" class="sa-form-input" id="renew-end"/></div>
        <div class="sa-form-group full"><label class="sa-form-label">Notes</label><textarea class="sa-form-textarea" id="renew-notes" placeholder="e.g. Paid via MTN MoMo"></textarea></div>
      </div>
    </div>
    <div class="sa-modal-footer"><button class="sa-btn sa-btn-outline" data-close-modal>Cancel</button><button class="sa-btn sa-btn-teal" onclick="saveRenewal()">✅ Confirm Renewal</button></div>
  </div>
</div>

<!-- Add Business -->
<div class="sa-modal-overlay" id="add-business-modal">
  <div class="sa-modal sa-modal-lg">
    <div class="sa-modal-header"><h2 class="sa-modal-title">Add New Business</h2><button class="sa-modal-close" data-close-modal>✕</button></div>
    <div class="sa-modal-body">
      <div class="sa-form-grid">
        <div class="sa-form-group"><label class="sa-form-label">Business Name *</label><input type="text" class="sa-form-input" id="add-biz-name" placeholder="e.g. Simba Restaurant"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Business Type *</label><select class="sa-form-select" id="add-biz-type-sel"><option value="">Select type…</option><option>Restaurant</option><option>Salon</option><option>Boutique</option><option>Snack Bar</option><option>Retail</option><option>Fashion</option><option>Other</option></select></div>
        <div class="sa-form-group"><label class="sa-form-label">Owner Full Name *</label><input type="text" class="sa-form-input" id="add-owner-name" placeholder="Full name"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Owner Login ID *</label><input type="text" class="sa-form-input" id="add-owner-login" placeholder="Email, phone, or username"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Phone</label><input type="tel" class="sa-form-input" id="add-owner-phone" placeholder="+237 6XX XXX XXX"/></div>
        <div class="sa-form-group"><label class="sa-form-label">City</label><input type="text" class="sa-form-input" id="add-biz-city" placeholder="e.g. Douala"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Owner Password *</label><input type="password" class="sa-form-input" id="add-owner-pwd" placeholder="Min. 8 characters"/></div>
        <div class="sa-form-group"><label class="sa-form-label">Subscription Plan</label><select class="sa-form-select" id="add-sub-plan"><option value="trial">Trial (30 days free)</option><option value="standard">Standard — 10,000 XAF/month</option></select></div>
      </div>
    </div>
    <div class="sa-modal-footer"><button class="sa-btn sa-btn-outline" data-close-modal>Cancel</button><button class="sa-btn sa-btn-primary" onclick="submitAddBusiness()">➕ Create Business</button></div>
  </div>
</div>

<div class="sa-toast" id="sa-toast"></div>
<script src="super_admin.js"></script>
</body>
</html>
