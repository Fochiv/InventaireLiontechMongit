<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$sidebarRole = $_SESSION['role'] ?? '';

$isOwner = $sidebarRole === 'business_owner';
$isManager = $sidebarRole === 'manager';
$isEmployee = $sidebarRole === 'employee';
$isOwnerOrMgr = $isOwner || $isManager;

$url = defined('APP_URL') ? APP_URL : '';

$L = [
    'employee_dash' => $url . '/LionTech_Employee_Dashboard/employee_dashboard.php',
    'owner_dash'    => $url . '/LionTech_Owner_Dashboard/owner_dashboard.php',

    'attendance'    => $url . '/Attendance_presenceemployer/clock_attendance.php',
    'employees'     => $url . '/LionTech_Employee_Management/employees.php',

    'products'      => $url . '/Produit/products.php',
    'stock_in'      => $url . '/LionTech_Stock_In_Page/stock_in.php',
    'stock_out'     => $url . '/stockout_stockfinis/stock_out.php',

    'notifications' => $url . '/LionTech_Complete_MVP_Remaining_Pages/notifications.php',
    'validations'   => $url . '/LionTech_Complete_MVP_Remaining_Pages/approval_center.php',
    'reports'       => $url . '/LionTech_Complete_MVP_Remaining_Pages/reports.php',
    'activity'      => $url . '/LionTech_Complete_MVP_Remaining_Pages/activity_logs.php',
    'subscription'  => $url . '/LionTech_Complete_MVP_Remaining_Pages/subscription_billing.php',
    'settings'      => $url . '/LionTech_Complete_MVP_Remaining_Pages/settings.php',

    'change_pin'    => $url . '/change_pin.php',
    'logout'        => $url . '/Logininventory/logout.php',
];

$sidebarUser = function_exists('currentUser') ? currentUser() : [];
$sidebarFullName = $sidebarUser['full_name'] ?? 'User';

$sidebarInitials = '';
foreach (explode(' ', trim($sidebarFullName)) as $w) {
    $sidebarInitials .= strtoupper(substr($w, 0, 1));
}
$sidebarInitials = substr($sidebarInitials ?: 'U', 0, 2);

$sidebarBizName = $business['business_name']
    ?? $sidebarUser['business_name']
    ?? ucfirst(str_replace('_', ' ', $sidebarRole));

if (!function_exists('sbActive')) {
    function sbActive(string $page, string $current): string {
        return $current === $page ? ' active' : '';
    }
}

if (!function_exists('sbIcon')) {
    function sbIcon(string $name): string {
        $icons = [
            'home' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
            'clock' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
            'users' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/></svg>',
            'package' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>',
            'arrow-down' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="8 12 12 16 16 12"/><line x1="12" y1="8" x2="12" y2="16"/></svg>',
            'arrow-up' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="16 12 12 8 8 12"/><line x1="12" y1="16" x2="12" y2="8"/></svg>',
            'bell' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
            'check' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
            'bar-chart' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
            'file-text' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
            'credit-card' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>',
            'settings' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82"/></svg>',
            'lock' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
            'log-out' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
        ];

        return $icons[$name] ?? '';
    }
}
?>

<link rel="stylesheet" href="<?= $url ?>/LionTech_Owner_Dashboard/owner_dashboard.css"/>

<div id="od-overlay" style="display:none;position:fixed;inset:0;z-index:29;background:rgba(11,31,58,.52);backdrop-filter:blur(3px)"></div>

<aside class="od-sidebar" id="od-sidebar">

  <div class="od-sidebar-header">
    <div class="od-logo">
      <img src="<?= $url ?>/Image/logo_lionTechhead.jpeg" alt="LionTech"
           style="width:46px;height:46px;border-radius:50%;object-fit:cover;">
      <div>
        <div class="od-logo-name">LionTech</div>
        <div class="od-logo-tag">Business Manager</div>
      </div>
    </div>

    <button class="od-sidebar-close" id="od-sidebar-close" aria-label="Close">×</button>
  </div>

  <nav class="od-nav">

    <div class="od-nav-section" data-i18n="nav_section_main">Principal</div>

    <?php if ($isEmployee): ?>
      <a class="od-nav-link<?= sbActive('employee_dashboard.php', $currentPage) ?>"
         href="<?= $L['employee_dash'] ?>">
        <?= sbIcon('home') ?><span data-i18n="nav_dashboard">Dashboard</span>
      </a>
    <?php else: ?>
      <a class="od-nav-link<?= sbActive('owner_dashboard.php', $currentPage) ?>"
         href="<?= $L['owner_dash'] ?>">
        <?= sbIcon('home') ?><span data-i18n="nav_dashboard">Dashboard</span>
      </a>
    <?php endif; ?>

    <a class="od-nav-link<?= sbActive('clock_attendance.php', $currentPage) ?>"
       href="<?= $L['attendance'] ?>">
      <?= sbIcon('clock') ?><span data-i18n="nav_attendance">Présence</span>
    </a>

    <a class="od-nav-link<?= sbActive('notifications.php', $currentPage) ?>"
       href="<?= $L['notifications'] ?>">
      <?= sbIcon('bell') ?><span data-i18n="nav_notifications">Notifications</span>
      <span id="lt-notif-badge"
            style="display:none;background:#DC2626;color:#fff;font-size:10px;font-weight:700;border-radius:50px;padding:1px 6px;margin-left:auto;min-width:18px;text-align:center">
      </span>
    </a>

    <div class="od-nav-section" data-i18n="nav_section_inventory">Inventaire</div>

    <a class="od-nav-link<?= sbActive('products.php', $currentPage) ?>"
       href="<?= $L['products'] ?>">
      <?= sbIcon('package') ?><span data-i18n="nav_products">Produits</span>
    </a>

    <a class="od-nav-link<?= sbActive('stock_in.php', $currentPage) ?>"
       href="<?= $L['stock_in'] ?>">
      <?= sbIcon('arrow-down') ?><span data-i18n="nav_stock_in">Stock entrant</span>
    </a>

    <a class="od-nav-link<?= sbActive('stock_out.php', $currentPage) ?>"
       href="<?= $L['stock_out'] ?>">
      <?= sbIcon('arrow-up') ?><span data-i18n="nav_stock_out">Stock sortant</span>
    </a>

    <?php if ($isOwnerOrMgr): ?>
      <div class="od-nav-section" data-i18n="nav_section_management">Gestion</div>

      <a class="od-nav-link<?= sbActive('employees.php', $currentPage) ?>"
         href="<?= $L['employees'] ?>">
        <?= sbIcon('users') ?><span data-i18n="nav_employees">Employés</span>
      </a>

      <a class="od-nav-link<?= sbActive('approval_center.php', $currentPage) ?>"
         href="<?= $L['validations'] ?>">
        <?= sbIcon('check') ?><span data-i18n="nav_validations">Validations</span>
      </a>

      <a class="od-nav-link<?= sbActive('reports.php', $currentPage) ?>"
         href="<?= $L['reports'] ?>">
        <?= sbIcon('bar-chart') ?><span data-i18n="nav_reports">Rapports</span>
      </a>

      <a class="od-nav-link<?= sbActive('activity_logs.php', $currentPage) ?>"
         href="<?= $L['activity'] ?>">
        <?= sbIcon('file-text') ?><span data-i18n="nav_activity">Activité</span>
      </a>
    <?php endif; ?>

    <?php if ($isOwner): ?>
      <div class="od-nav-section" data-i18n="nav_section_business">Business</div>

      <a class="od-nav-link<?= sbActive('subscription_billing.php', $currentPage) ?>"
         href="<?= $L['subscription'] ?>">
        <?= sbIcon('credit-card') ?><span data-i18n="nav_subscription">Abonnement</span>
      </a>

      <a class="od-nav-link<?= sbActive('settings.php', $currentPage) ?>"
         href="<?= $L['settings'] ?>">
        <?= sbIcon('settings') ?><span data-i18n="nav_settings">Paramètres</span>
      </a>
    <?php endif; ?>

    <div class="od-nav-section" data-i18n="nav_section_account">Compte</div>

    <a class="od-nav-link<?= sbActive('change_pin.php', $currentPage) ?>"
       href="<?= $L['change_pin'] ?>">
      <?= sbIcon('lock') ?><span data-i18n="nav_change_pin">Changer PIN</span>
    </a>

    <a class="od-nav-link logout" href="<?= $L['logout'] ?>">
      <?= sbIcon('log-out') ?><span data-i18n="nav_logout">Déconnexion</span>
    </a>

  </nav>

  <div class="od-sidebar-footer">
    <div class="od-avatar"><?= htmlspecialchars($sidebarInitials, ENT_QUOTES, 'UTF-8') ?></div>
    <div>
      <div class="od-sidebar-name"><?= htmlspecialchars($sidebarFullName, ENT_QUOTES, 'UTF-8') ?></div>
      <div class="od-sidebar-role"><?= htmlspecialchars($sidebarBizName, ENT_QUOTES, 'UTF-8') ?></div>
    </div>
  </div>

</aside>

<script>
(function () {
  const translations = {
    fr: {
      nav_section_main: 'Principal',
      nav_section_inventory: 'Inventaire',
      nav_section_management: 'Gestion',
      nav_section_business: 'Business',
      nav_section_account: 'Compte',
      nav_dashboard: 'Dashboard',
      nav_attendance: 'Présence',
      nav_notifications: 'Notifications',
      nav_products: 'Produits',
      nav_stock_in: 'Stock entrant',
      nav_stock_out: 'Stock sortant',
      nav_employees: 'Employés',
      nav_validations: 'Validations',
      nav_reports: 'Rapports',
      nav_activity: 'Activité',
      nav_subscription: 'Abonnement',
      nav_settings: 'Paramètres',
      nav_change_pin: 'Changer PIN',
      nav_logout: 'Déconnexion'
    },
    en: {
      nav_section_main: 'Main',
      nav_section_inventory: 'Inventory',
      nav_section_management: 'Management',
      nav_section_business: 'Business',
      nav_section_account: 'Account',
      nav_dashboard: 'Dashboard',
      nav_attendance: 'Attendance',
      nav_notifications: 'Notifications',
      nav_products: 'Products',
      nav_stock_in: 'Stock In',
      nav_stock_out: 'Stock Out',
      nav_employees: 'Employees',
      nav_validations: 'Approvals',
      nav_reports: 'Reports',
      nav_activity: 'Activity',
      nav_subscription: 'Subscription',
      nav_settings: 'Settings',
      nav_change_pin: 'Change PIN',
      nav_logout: 'Logout'
    }
  };

  function applySidebarLang() {
    const lang = localStorage.getItem('lt_lang') || 'en';

    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      const key = el.dataset.i18n;
      if (translations[lang] && translations[lang][key]) {
        el.textContent = translations[lang][key];
      }
    });
  }

  applySidebarLang();

  window.addEventListener('storage', function (e) {
    if (e.key === 'lt_lang') applySidebarLang();
  });

  window.applySidebarLang = applySidebarLang;
})();
</script>

<script>
(function () {
  if (window._sidebarBound) return;
  window._sidebarBound = true;

  const sidebar  = document.getElementById('od-sidebar');
  const overlay  = document.getElementById('od-overlay');
  const menuBtn  = document.getElementById('od-menu-btn');
  const closeBtn = document.getElementById('od-sidebar-close');

  function openSidebar() {
    if (sidebar) sidebar.classList.add('open');
    if (overlay) overlay.style.display = 'block';
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.style.display = 'none';
    document.body.style.overflow = '';
  }

  if (menuBtn) menuBtn.addEventListener('click', openSidebar);
  if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
  if (overlay) overlay.addEventListener('click', closeSidebar);

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSidebar();
  });
})();
</script>

<script>
(function () {
  const api = '<?= $url ?>/LionTech_Complete_MVP_Remaining_Pages/notifications_api.php';
  const badge = document.getElementById('lt-notif-badge');

  if (!badge) return;

  function fetchNotifs() {
    fetch(api, { credentials: 'same-origin' })
      .then(r => r.json())
      .then(data => {
        if (data.unread > 0) {
          badge.textContent = data.unread > 99 ? '99+' : data.unread;
          badge.style.display = 'inline-block';
        } else {
          badge.style.display = 'none';
        }
      })
      .catch(() => {});
  }

  fetchNotifs();
  setInterval(fetchNotifs, 30000);
})();
</script>