<?php
require_once __DIR__ . '/../Config.php';
startSecureSession();

if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/Logininventory/login.php?error=session_expired');
    exit;
}

$pdo = getDB();
$user = currentUser();

$role = $_SESSION['role'] ?? '';
$businessId = (int)($_SESSION['business_id'] ?? ($user['business_id'] ?? 0));
$userId = (int)($_SESSION['user_id'] ?? ($user['user_id'] ?? 0));

$allowedRoles = [ROLE_BUSINESS_OWNER, ROLE_MANAGER, ROLE_EMPLOYEE];

if (!in_array($role, $allowedRoles, true) || $businessId <= 0 || $userId <= 0) {
    header('Location: ' . APP_URL . '/Logininventory/login.php?error=unauthorized');
    exit;
}

if (!function_exists('e')) {
    function e($value): string {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

function qfmt($value): string {
    return rtrim(rtrim(number_format((float)$value, 2, '.', ''), '0'), '.');
}

function slugFileName(string $name): string {
    $name = strtolower(trim($name));
    $name = preg_replace('/[^a-z0-9\._-]+/', '-', $name);
    return trim($name, '-');
}

function uploadProofFile(string $inputName): ?string {
    if (!isset($_FILES[$inputName]) || $_FILES[$inputName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($_FILES[$inputName]['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Proof upload failed.');
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf'
    ];

    $mime = mime_content_type($_FILES[$inputName]['tmp_name']);

    if (!isset($allowed[$mime])) {
        throw new Exception('Only JPG, PNG, WEBP, or PDF files are allowed.');
    }

    if ($_FILES[$inputName]['size'] > 3 * 1024 * 1024) {
        throw new Exception('Proof file must be less than 3MB.');
    }

    $uploadDir = __DIR__ . '/uploads/stock_out';
    $uploadUrlBase = 'uploads/stock_out';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0775, true);
    }

    $originalName = slugFileName($_FILES[$inputName]['name']);
    $fileName = time() . '-' . random_int(1000, 9999) . '-' . $originalName;
    $target = $uploadDir . '/' . $fileName;

    if (!move_uploaded_file($_FILES[$inputName]['tmp_name'], $target)) {
        throw new Exception('Could not save proof file.');
    }

    return $uploadUrlBase . '/' . $fileName;
}

$success = '';
$error = '';

$isEmployee = ($role === ROLE_EMPLOYEE);
$isApprover = in_array($role, [ROLE_BUSINESS_OWNER, ROLE_MANAGER], true);

try {
    $stmt = $pdo->prepare("SELECT * FROM businesses WHERE business_id = ? LIMIT 1");
    $stmt->execute([$businessId]);
    $business = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$business) {
        header('Location: ' . APP_URL . '/Logininventory/login.php?error=unauthorized');
        exit;
    }

    $subscriptionStatus = $business['subscription_status'] ?? 'active';
    $isExpired = in_array($subscriptionStatus, ['expired', 'suspended'], true);

    $inventoryEnabled = true;

    try {
        $stmt = $pdo->prepare("SELECT inventory_management FROM business_features WHERE business_id = ? LIMIT 1");
        $stmt->execute([$businessId]);
        $feature = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($feature && (int)$feature['inventory_management'] !== 1) {
            $inventoryEnabled = false;
        }
    } catch (Throwable $e) {
        $inventoryEnabled = true;
    }

    $canCreate = $inventoryEnabled && !$isExpired;
    $canApprove = $isApprover && $inventoryEnabled && !$isExpired;

    /* CREATE STOCK OUT */
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_stock_out') {
        if (!$canCreate) {
            throw new Exception('This action is disabled.');
        }

        $productId = (int)($_POST['product_id'] ?? 0);
        $quantity = (float)($_POST['quantity'] ?? 0);
        $reason = trim($_POST['reason'] ?? '');
        $recipient = trim($_POST['recipient'] ?? '');
        $note = trim($_POST['note'] ?? '');

        if ($productId <= 0) {
            throw new Exception('Please select a product.');
        }

        if ($quantity <= 0) {
            throw new Exception('Quantity must be greater than zero.');
        }

        $allowedReasons = ['Sold', 'Used', 'Damaged', 'Expired', 'Missing/Lost', 'Returned'];

        if (!in_array($reason, $allowedReasons, true)) {
            throw new Exception('Please select a valid stock-out reason.');
        }

        $stmt = $pdo->prepare("
            SELECT product_id, name, quantity, unit
            FROM products
            WHERE product_id = ?
              AND business_id = ?
              AND status = 'active'
            LIMIT 1
        ");
        $stmt->execute([$productId, $businessId]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            throw new Exception('Product not found for this business.');
        }

        if ($quantity > (float)$product['quantity']) {
            throw new Exception('Stock out quantity cannot be higher than available stock.');
        }

        $proofPath = uploadProofFile('proof_file');

        $needsApproval = $isEmployee;
        $status = $needsApproval ? 'pending' : 'approved';
        $approvedBy = $needsApproval ? null : $userId;
        $approvedAt = $needsApproval ? null : date('Y-m-d H:i:s');

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            INSERT INTO stock_out_requests (
                business_id,
                product_id,
                quantity,
                reason,
                recipient,
                note,
                proof_image_url,
                status,
                created_by,
                approved_by,
                approved_at,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");

        $stmt->execute([
            $businessId,
            $productId,
            $quantity,
            $reason,
            $recipient ?: null,
            $note ?: null,
            $proofPath,
            $status,
            $userId,
            $approvedBy,
            $approvedAt
        ]);

        $requestId = (int)$pdo->lastInsertId();

        if (!$needsApproval) {
            $stmt = $pdo->prepare("
                UPDATE products
                SET quantity = quantity - ?,
                    updated_at = NOW()
                WHERE product_id = ?
                  AND business_id = ?
            ");
            $stmt->execute([$quantity, $productId, $businessId]);

            $stmt = $pdo->prepare("
                INSERT INTO stock_movements (
                    request_id,
                    business_id,
                    product_id,
                    movement_type,
                    quantity,
                    reason,
                    proof_image_url,
                    created_by,
                    approved_by,
                    created_at
                ) VALUES (?, ?, ?, 'stock_out', ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $requestId,
                $businessId,
                $productId,
                $quantity,
                $reason,
                $proofPath,
                $userId,
                $userId
            ]);

            $success = 'Stock out recorded successfully and inventory updated.';
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (
                        business_id,
                        title,
                        message,
                        type,
                        created_at
                    ) VALUES (?, 'Stock Out Approval Needed', ?, 'warning', NOW())
                ");
                $stmt->execute([
                    $businessId,
                    'An employee submitted a stock out request for ' . $product['name'] . '.'
                ]);
            } catch (Throwable $e) {}

            $success = 'Stock out request submitted. Waiting for owner/manager approval.';
        }

        $pdo->commit();
    }

    /* APPROVE STOCK OUT */
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'approve_stock_out') {
        if (!$canApprove) {
            throw new Exception('You do not have permission to approve stock out requests.');
        }

        $requestId = (int)($_POST['request_id'] ?? 0);

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            SELECT so.*, p.quantity AS current_quantity
            FROM stock_out_requests so
            JOIN products p ON p.product_id = so.product_id
            WHERE so.request_id = ?
              AND so.business_id = ?
              AND so.status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$requestId, $businessId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            throw new Exception('Request not found or already processed.');
        }

        if ((float)$request['quantity'] > (float)$request['current_quantity']) {
            throw new Exception('Cannot approve. Requested quantity is higher than available stock.');
        }

        $stmt = $pdo->prepare("
            UPDATE products
            SET quantity = quantity - ?,
                updated_at = NOW()
            WHERE product_id = ?
              AND business_id = ?
        ");
        $stmt->execute([
            (float)$request['quantity'],
            (int)$request['product_id'],
            $businessId
        ]);

        $stmt = $pdo->prepare("
            UPDATE stock_out_requests
            SET status = 'approved',
                approved_by = ?,
                approved_at = NOW()
            WHERE request_id = ?
              AND business_id = ?
        ");
        $stmt->execute([$userId, $requestId, $businessId]);

        $stmt = $pdo->prepare("
            INSERT INTO stock_movements (
                request_id,
                business_id,
                product_id,
                movement_type,
                quantity,
                reason,
                proof_image_url,
                created_by,
                approved_by,
                created_at
            ) VALUES (?, ?, ?, 'stock_out', ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $requestId,
            $businessId,
            (int)$request['product_id'],
            (float)$request['quantity'],
            $request['reason'],
            $request['proof_image_url'],
            (int)$request['created_by'],
            $userId
        ]);

        $pdo->commit();

        $success = 'Stock out approved. Inventory updated.';
    }

    /* REJECT STOCK OUT */
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reject_stock_out') {
        if (!$canApprove) {
            throw new Exception('You do not have permission to reject stock out requests.');
        }

        $requestId = (int)($_POST['request_id'] ?? 0);
        $reason = trim($_POST['rejection_reason'] ?? 'Rejected after review');

        $stmt = $pdo->prepare("
            UPDATE stock_out_requests
            SET status = 'rejected',
                approved_by = ?,
                approved_at = NOW(),
                rejection_reason = ?
            WHERE request_id = ?
              AND business_id = ?
              AND status = 'pending'
        ");
        $stmt->execute([$userId, $reason, $requestId, $businessId]);

        $success = 'Stock out request rejected.';
    }

    /* LOAD PRODUCTS */
    $stmt = $pdo->prepare("
        SELECT product_id, name, category, quantity, unit, low_stock_level, image_url
        FROM products
        WHERE business_id = ?
          AND status = 'active'
        ORDER BY name ASC
    ");
    $stmt->execute([$businessId]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /* LOAD HISTORY */
    $stmt = $pdo->prepare("
        SELECT
            so.*,
            p.name AS product_name,
            p.unit,
            p.category,
            u.full_name AS requested_by_name,
            a.full_name AS approved_by_name
        FROM stock_out_requests so
        JOIN products p ON p.product_id = so.product_id
        LEFT JOIN users u ON u.user_id = so.created_by
        LEFT JOIN users a ON a.user_id = so.approved_by
        WHERE so.business_id = ?
        ORDER BY so.created_at DESC
        LIMIT 100
    ");
    $stmt->execute([$businessId]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $ex) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $error = $ex->getMessage();
    $products = $products ?? [];
    $history = $history ?? [];
    $business = $business ?? [];
    $inventoryEnabled = $inventoryEnabled ?? true;
    $isExpired = $isExpired ?? false;
    $canCreate = $canCreate ?? false;
    $canApprove = $canApprove ?? false;
}

$pendingCount = count(array_filter($history, fn($r) => $r['status'] === 'pending'));
$approvedToday = count(array_filter($history, fn($r) => $r['status'] === 'approved' && substr((string)$r['approved_at'], 0, 10) === date('Y-m-d')));
$totalPendingQty = array_sum(array_map(fn($r) => $r['status'] === 'pending' ? (float)$r['quantity'] : 0, $history));

$initials = '';
foreach (explode(' ', trim($user['full_name'] ?? 'U')) as $w) {
    $initials .= strtoupper(substr($w, 0, 1));
}
$initials = substr($initials ?: 'U', 0, 2);
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sortie de Stock — LionTech</title>
    <link rel="stylesheet" href="stock_out.css">
</head>

<body>
<div class="od-layout">

<?php include __DIR__ . '/../LionTech_Owner_Dashboard/Sidebar.php'; ?>

<main class="od-main">

    <header class="od-topbar">
        <button class="od-menu-btn" id="od-menu-btn">☰</button>

        <div class="od-business-title">
            <h1 data-i18n="page_title">Sortie de Stock</h1>
            <p data-i18n="page_subtitle">Enregistrez les produits vendus, utilisés, abîmés, expirés ou perdus.</p>
        </div>

        <div class="od-top-actions">
            <button id="langBtn" class="od-lang">EN</button>
            <div class="od-avatar"><?= e($initials) ?></div>
        </div>
    </header>

    <?php if (!$inventoryEnabled): ?>
        <div style="padding:40px 24px;text-align:center">
            <div style="font-size:40px">🔒</div>
            <h2 style="color:#0B1F3A">Inventaire non activé</h2>
            <p style="color:#6B7280;font-size:14px">Contactez LionTech pour activer cette fonctionnalité.</p>
        </div>
    <?php else: ?>

    <?php if ($isExpired): ?>
        <div style="background:#FEF3C7;border:1px solid #FDE68A;padding:12px 24px;font-size:13px;color:#92400E">
            ⚠️ Abonnement expiré. Vous pouvez consulter l'historique mais les nouvelles actions sont désactivées.
        </div>
    <?php endif; ?>

    <?php if ($isEmployee): ?>
        <div style="background:#FEF3C7;border:1px solid #FDE68A;padding:12px 24px;font-size:13px;color:#92400E">
            ⚠️ Les sorties de stock enregistrées par un employé doivent être approuvées avant de modifier l'inventaire.
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div style="background:#F0FDF4;border:1px solid #86EFAC;padding:12px 24px;font-size:13px;color:#166534">
            ✅ <?= e($success) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div style="background:#FEF2F2;border:1px solid #FECACA;padding:12px 24px;font-size:13px;color:#991B1B">
            ⚠️ <?= e($error) ?>
        </div>
    <?php endif; ?>

    <section style="padding:20px 24px 0;display:grid;grid-template-columns:repeat(4,1fr);gap:14px">
        <div class="od-card stat">
            <span class="stat-icon amber">⏳</span>
            <div>
                <small>Demandes en attente</small>
                <strong><?= (int)$pendingCount ?></strong>
            </div>
        </div>

        <div class="od-card stat">
            <span class="stat-icon green">✅</span>
            <div>
                <small>Approuvés aujourd'hui</small>
                <strong><?= (int)$approvedToday ?></strong>
            </div>
        </div>

        <div class="od-card stat">
            <span class="stat-icon blue">📦</span>
            <div>
                <small>Produits actifs</small>
                <strong><?= count($products) ?></strong>
            </div>
        </div>

        <div class="od-card stat">
            <span class="stat-icon" style="background:#EDE9FE">➖</span>
            <div>
                <small>Qté en attente</small>
                <strong><?= qfmt($totalPendingQty) ?></strong>
            </div>
        </div>
    </section>

    <div style="padding:20px 24px 40px;display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start">

        <section class="od-card" style="padding:28px">
            <h2 style="font-size:17px;font-weight:700;color:#0B1F3A;margin-bottom:20px">
                Nouvelle sortie de stock
            </h2>

            <form method="POST" enctype="multipart/form-data" id="stockOutForm" style="display:flex;flex-direction:column;gap:14px">
                <input type="hidden" name="action" value="create_stock_out">

                <div>
                    <label style="font-size:12px;font-weight:600;color:#0B1F3A;display:block;margin-bottom:5px">
                        Produit *
                    </label>
                    <select name="product_id" id="productSelect" required style="width:100%;padding:10px 13px;border:1.5px solid #E5E7EB;border-radius:10px;font-size:13.5px;font-family:inherit">
                        <option value="">Sélectionner un produit</option>
                        <?php foreach ($products as $p): ?>
                            <option value="<?= (int)$p['product_id'] ?>"
                                    data-qty="<?= e($p['quantity']) ?>"
                                    data-unit="<?= e($p['unit'] ?? '') ?>">
                                <?= e($p['name']) ?> — <?= qfmt($p['quantity']) ?> <?= e($p['unit'] ?? '') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div id="stockInfo" style="font-size:12px;color:#6B7280;padding:8px 12px;background:#F8FAFC;border-radius:8px">
                    Stock disponible: --
                </div>

                <div>
                    <label style="font-size:12px;font-weight:600;color:#0B1F3A;display:block;margin-bottom:5px">
                        Quantité sortie *
                    </label>
                    <input type="number" step="0.01" min="0.01" name="quantity" id="quantityInput" required style="width:100%;padding:10px 13px;border:1.5px solid #E5E7EB;border-radius:10px;font-size:13.5px;font-family:inherit">
                </div>

                <div>
                    <label style="font-size:12px;font-weight:600;color:#0B1F3A;display:block;margin-bottom:5px">
                        Raison *
                    </label>
                    <select name="reason" required style="width:100%;padding:10px 13px;border:1.5px solid #E5E7EB;border-radius:10px;font-size:13.5px;font-family:inherit">
                        <option value="">Choisir une raison</option>
                        <option value="Sold">Vendu</option>
                        <option value="Used">Utilisé</option>
                        <option value="Damaged">Abîmé</option>
                        <option value="Expired">Expiré</option>
                        <option value="Missing/Lost">Manquant / Perdu</option>
                        <option value="Returned">Retourné</option>
                    </select>
                </div>

                <div>
                    <label style="font-size:12px;font-weight:600;color:#0B1F3A;display:block;margin-bottom:5px">
                        Client / Destination
                    </label>
                    <input type="text" name="recipient" placeholder="Ex: Client, Cuisine, Bar" style="width:100%;padding:10px 13px;border:1.5px solid #E5E7EB;border-radius:10px;font-size:13.5px;font-family:inherit">
                </div>

                <div>
                    <label style="font-size:12px;font-weight:600;color:#0B1F3A;display:block;margin-bottom:5px">
                        Preuve / photo / reçu
                    </label>
                    <input type="file" name="proof_file" accept="image/*,.pdf" style="width:100%">
                </div>

                <div>
                    <label style="font-size:12px;font-weight:600;color:#0B1F3A;display:block;margin-bottom:5px">
                        Note
                    </label>
                    <textarea name="note" rows="3" placeholder="Ajouter une note si nécessaire" style="width:100%;padding:10px 13px;border:1.5px solid #E5E7EB;border-radius:10px;font-size:13.5px;font-family:inherit;resize:vertical"></textarea>
                </div>

                <button type="submit"
                        class="od-primary"
                        style="padding:13px;font-size:14px;font-weight:700;border:none;cursor:pointer;border-radius:12px"
                        <?= !$canCreate ? 'disabled' : '' ?>>
                    Enregistrer la sortie
                </button>
            </form>
        </section>

        <aside class="od-card" style="padding:24px">
            <h2 style="font-size:15px;font-weight:700;color:#0B1F3A;margin-bottom:12px">
                À quoi sert cette page?
            </h2>
            <p style="font-size:13px;color:#6B7280;margin-bottom:12px">
                Enregistre tout ce qui sort du stock: produits vendus, utilisés, abîmés, expirés ou perdus.
            </p>
            <ul style="font-size:13px;color:#6B7280;padding-left:16px;display:flex;flex-direction:column;gap:6px">
                <li>Empêche les sorties supérieures au stock disponible.</li>
                <li>Garde un historique de qui a enregistré la sortie.</li>
                <li>Demande une approbation si l'action vient d'un employé.</li>
                <li>Met à jour l'inventaire immédiatement pour owner/manager.</li>
            </ul>
        </aside>

    </div>

    <section style="padding:0 24px 40px">
        <div class="od-card" style="padding:0;overflow:hidden">

            <div style="padding:18px 20px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #F1F5F9;flex-wrap:wrap;gap:10px">
                <div>
                    <h2 style="font-size:15px;font-weight:700;color:#0B1F3A;margin:0">
                        Historique des sorties
                    </h2>
                    <p style="font-size:12px;color:#6B7280;margin:3px 0 0">
                        Demandes, approbations et preuves de sorties de stock.
                    </p>
                </div>

                <input type="search" id="searchHistory" placeholder="Rechercher..." style="padding:8px 13px;border:1.5px solid #E5E7EB;border-radius:9px;font-size:13px;font-family:inherit">
            </div>

            <div style="overflow-x:auto">
                <table id="historyTable" style="width:100%;border-collapse:collapse;font-size:13px;min-width:900px">
                    <thead>
                        <tr style="background:#F8FAFC;border-bottom:1.5px solid #E5E7EB">
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Produit</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Quantité</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Raison</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Soumis par</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Statut</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Preuve</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Date</th>
                            <th style="padding:10px 16px;text-align:left;font-size:11px;font-weight:700;color:#6B7280;text-transform:uppercase">Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if ($history): ?>
                            <?php foreach ($history as $h): ?>
                                <tr data-search="<?= e(strtolower(($h['product_name'] ?? '') . ' ' . ($h['reason'] ?? '') . ' ' . ($h['requested_by_name'] ?? '') . ' ' . ($h['status'] ?? ''))) ?>">
                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <strong><?= e($h['product_name'] ?? '—') ?></strong><br>
                                        <small style="color:#6B7280"><?= e($h['category'] ?? '') ?></small>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?= qfmt($h['quantity']) ?> <?= e($h['unit'] ?? '') ?>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?= e($h['reason'] ?? '—') ?>
                                        <?php if (!empty($h['recipient'])): ?>
                                            <br><small style="color:#6B7280">Destination: <?= e($h['recipient']) ?></small>
                                        <?php endif; ?>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?= e($h['requested_by_name'] ?? '—') ?>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?php
                                            $badgeBg = '#FEF3C7';
                                            $badgeColor = '#92400E';

                                            if ($h['status'] === 'approved') {
                                                $badgeBg = '#DCFCE7';
                                                $badgeColor = '#166534';
                                            } elseif ($h['status'] === 'rejected') {
                                                $badgeBg = '#FEE2E2';
                                                $badgeColor = '#991B1B';
                                            }
                                        ?>
                                        <span style="display:inline-block;padding:4px 10px;border-radius:999px;background:<?= $badgeBg ?>;color:<?= $badgeColor ?>;font-size:11px;font-weight:800">
                                            <?= ucfirst(e($h['status'])) ?>
                                        </span>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?php if (!empty($h['proof_image_url'])): ?>
                                            <a href="<?= APP_URL ?>/stockout_stockfinis/<?= e($h['proof_image_url']) ?>"
                                               target="_blank"
                                               style="color:#1A9E7A;font-weight:700;text-decoration:none">
                                                Voir
                                            </a>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?= e(substr((string)$h['created_at'], 0, 16)) ?>
                                        <?php if (!empty($h['approved_at'])): ?>
                                            <br><small style="color:#6B7280">Approuvé: <?= e(substr((string)$h['approved_at'], 0, 16)) ?></small>
                                        <?php endif; ?>
                                    </td>

                                    <td style="padding:12px 16px;border-bottom:1px solid #F1F5F9">
                                        <?php if ($h['status'] === 'pending' && $canApprove): ?>
                                            <div style="display:flex;gap:6px;flex-wrap:wrap">
                                                <form method="POST">
                                                    <input type="hidden" name="action" value="approve_stock_out">
                                                    <input type="hidden" name="request_id" value="<?= (int)$h['request_id'] ?>">
                                                    <button type="submit" style="padding:5px 10px;font-size:12px;background:#F0FDF4;border:1.5px solid #86EFAC;border-radius:8px;color:#166534;cursor:pointer">
                                                        Approuver
                                                    </button>
                                                </form>

                                                <form method="POST">
                                                    <input type="hidden" name="action" value="reject_stock_out">
                                                    <input type="hidden" name="request_id" value="<?= (int)$h['request_id'] ?>">
                                                    <input type="hidden" name="rejection_reason" value="Rejeté après vérification">
                                                    <button type="submit" style="padding:5px 10px;font-size:12px;background:#FEF2F2;border:1.5px solid #FECACA;border-radius:8px;color:#991B1B;cursor:pointer">
                                                        Rejeter
                                                    </button>
                                                </form>
                                            </div>
                                        <?php elseif ($h['status'] === 'pending'): ?>
                                            <small style="color:#6B7280">En attente d'approbation</small>
                                        <?php elseif ($h['status'] === 'approved'): ?>
                                            <small style="color:#166534">✅ <?= e($h['approved_by_name'] ?? 'Approuvé') ?></small>
                                        <?php else: ?>
                                            <small style="color:#991B1B"><?= e($h['rejection_reason'] ?? 'Rejeté') ?></small>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align:center;color:#6B7280;padding:28px">
                                    Aucune sortie de stock enregistrée.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </section>

    <?php endif; ?>

</main>
</div>

<script>
const productSelect = document.getElementById('productSelect');
const stockInfo = document.getElementById('stockInfo');
const quantityInput = document.getElementById('quantityInput');

productSelect?.addEventListener('change', function () {
    const opt = this.options[this.selectedIndex];
    const qty = opt?.dataset?.qty || '--';
    const unit = opt?.dataset?.unit || '';

    if (stockInfo) {
        stockInfo.textContent = 'Stock disponible: ' + qty + ' ' + unit;
    }

    if (quantityInput && qty !== '--') {
        quantityInput.max = qty;
    }
});

document.getElementById('searchHistory')?.addEventListener('input', function () {
    const q = this.value.toLowerCase();

    document.querySelectorAll('#historyTable tbody tr').forEach(row => {
        const text = row.dataset.search || row.textContent.toLowerCase();
        row.style.display = text.includes(q) ? '' : 'none';
    });
});

document.getElementById('od-menu-btn')?.addEventListener('click', () => {
    const sb = document.getElementById('od-sidebar') || document.querySelector('.od-sidebar');
    const overlay = document.getElementById('od-overlay');

    sb?.classList.toggle('open');

    if (overlay) {
        overlay.style.display = sb?.classList.contains('open') ? 'block' : 'none';
    }
});

document.getElementById('od-overlay')?.addEventListener('click', () => {
    const sb = document.getElementById('od-sidebar') || document.querySelector('.od-sidebar');
    const overlay = document.getElementById('od-overlay');

    sb?.classList.remove('open');

    if (overlay) {
        overlay.style.display = 'none';
    }
});
</script>

</body>
</html>