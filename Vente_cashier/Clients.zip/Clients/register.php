<?php
require_once __DIR__ . '/config_client.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = normalize_phone($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $phone === '' || strlen($password) < 4) {
        $error = 'Veuillez entrer un nom, un numéro WhatsApp et un mot de passe de 4 caractères minimum.';
    } else {
        try {
            $pdo = client_pdo();
            $stmt = $pdo->prepare('SELECT client_id FROM lbm_clients WHERE phone = ? LIMIT 1');
            $stmt->execute([$phone]);
            $existing = $stmt->fetch();

            if ($existing) {
                $_SESSION['client_id'] = (int)$existing['client_id'];
                header('Location: dashboard.php');
                exit;
            }

            $qrToken = bin2hex(random_bytes(16));
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare('INSERT INTO lbm_clients (full_name, phone, password_hash, qr_token, account_status, created_at) VALUES (?, ?, ?, ?, "active", NOW())');
            $insert->execute([$name, $phone, $hash, $qrToken]);
            $_SESSION['client_id'] = (int)$pdo->lastInsertId();
            header('Location: dashboard.php?created=1');
            exit;
        } catch (Throwable $e) {
            $error = 'Erreur: ' . $e->getMessage();
        }
    }
}

$pageTitle = 'Create Account';
include __DIR__ . '/partials/header.php';
?>
<main class="single-card-wrap">
    <section class="card auth-card wide">
        <a class="back-btn" href="index.php">← <span data-i18n="back">Retour</span></a>
        <h1 data-i18n="create_account">Créer un compte</h1>
        <p class="muted" data-i18n="account_benefit">Gardez vos reçus, retrouvez-les plus tard et utilisez votre QR code client.</p>
        <?php if ($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
        <form method="post" class="form-stack">
            <label>
                <span data-i18n="full_name">Nom complet</span>
                <input type="text" name="name" required placeholder="Marie Ndongo" autocomplete="name">
            </label>
            <label>
                <span data-i18n="whatsapp_number">Numéro WhatsApp</span>
                <input type="tel" name="phone" required placeholder="+237699000000" autocomplete="tel">
            </label>
            <label>
                <span data-i18n="password_pin">Mot de passe / PIN</span>
                <input type="password" name="password" required minlength="4" placeholder="4 caractères minimum">
            </label>
            <button class="btn primary" type="submit" data-i18n="create_my_account">Créer mon compte</button>
        </form>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
