<?php
require_once __DIR__ . '/config_client.php';
$pageTitle = 'Client Receipt Center';
include __DIR__ . '/partials/header.php';
?>
<main class="hero-layout">
    <section class="hero-card hero-gradient">
        <div class="logo-mark">
            <img src="../../Image/logo_lionTechhead.jpeg" alt="LionTech" onerror="this.style.display='none'">
        </div>
        <p class="eyebrow">LionTech Business Manager</p>
        <h1 data-i18n="hero_title">Tous vos reçus au même endroit.</h1>
        <p class="hero-text" data-i18n="hero_text">Entrez votre WhatsApp pour retrouver vos reçus, ou créez un compte pour garder un historique complet.</p>
        <div class="status-pill" id="networkStatus">● Online</div>
    </section>

    <section class="card auth-card">
        <h2 data-i18n="quick_access">Accès rapide</h2>
        <p class="muted" data-i18n="quick_access_text">Voir vos reçus avec votre numéro WhatsApp. Aucun mot de passe requis.</p>

        <form action="dashboard.php" method="get" class="form-stack">
            <label>
                <span data-i18n="whatsapp_number">Numéro WhatsApp</span>
                <input type="tel" name="phone" placeholder="Ex: +237699000000" required autocomplete="tel">
            </label>
            <button class="btn primary" type="submit" data-i18n="view_receipts">Voir mes reçus</button>
        </form>

        <div class="divider"><span data-i18n="or">ou</span></div>

        <div class="grid-2">
            <a class="btn soft" href="register.php" data-i18n="create_account">Créer un compte</a>
            <a class="btn ghost" href="login.php" data-i18n="login">Connexion</a>
        </div>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
