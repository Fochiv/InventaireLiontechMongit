<?php
require_once __DIR__ . '/config_client.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = normalize_phone($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    try {
        $pdo = client_pdo();
        $stmt = $pdo->prepare('SELECT * FROM lbm_clients WHERE phone = ? AND account_status = "active" LIMIT 1');
        $stmt->execute([$phone]);
        $client = $stmt->fetch();
        if ($client && password_verify($password, $client['password_hash'] ?? '')) {
            $_SESSION['client_id'] = (int)$client['client_id'];
            header('Location: dashboard.php');
            exit;
        }
        $error = 'Numéro ou mot de passe incorrect.';
    } catch (Throwable $e) {
        $error = 'Erreur: ' . $e->getMessage();
    }
}

$pageTitle = 'Client Login';
include __DIR__ . '/partials/header.php';
?>
<main class="single-card-wrap">
    <section class="card auth-card wide">
        <a class="back-btn" href="index.php">← <span data-i18n="back">Retour</span></a>
        <h1 data-i18n="login">Connexion</h1>
        <p class="muted" data-i18n="login_text">Connectez-vous pour voir votre historique complet.</p>
        <?php if ($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
        <form method="post" class="form-stack">
            <label>
                <span data-i18n="whatsapp_number">Numéro WhatsApp</span>
                <input type="tel" name="phone" required placeholder="+237699000000" autocomplete="tel">
            </label>
            <label>
                <span data-i18n="password_pin">Mot de passe / PIN</span>
                <input type="password" name="password" required>
            </label>
            <button class="btn primary" type="submit" data-i18n="login">Connexion</button>
        </form>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
