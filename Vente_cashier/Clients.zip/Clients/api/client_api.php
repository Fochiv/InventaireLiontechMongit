<?php
require_once __DIR__ . '/../config_client.php';
$action = $_GET['action'] ?? '';

try {
    $pdo = client_pdo();
    if ($action === 'find_by_phone') {
        $phone = normalize_phone($_GET['phone'] ?? '');
        $stmt = $pdo->prepare('SELECT client_id, full_name, phone, qr_token FROM lbm_clients WHERE phone = ? LIMIT 1');
        $stmt->execute([$phone]);
        json_response(['success' => true, 'client' => $stmt->fetch() ?: null]);
    }
    json_response(['success' => false, 'message' => 'Unknown action'], 400);
} catch (Throwable $e) {
    json_response(['success' => false, 'message' => $e->getMessage()], 500);
}
