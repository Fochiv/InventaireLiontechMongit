<?php
require_once __DIR__ . '/../config_client.php';
$action = $_GET['action'] ?? '';

try {
    $pdo = client_pdo();
    if ($action === 'by_phone') {
        $phone = normalize_phone($_GET['phone'] ?? '');
        $stmt = $pdo->prepare('SELECT * FROM lbm_client_receipts WHERE client_phone = ? ORDER BY sale_datetime DESC LIMIT 100');
        $stmt->execute([$phone]);
        json_response(['success' => true, 'receipts' => $stmt->fetchAll()]);
    }
    if ($action === 'mark_important') {
        $client = require_client();
        $id = (int)($_POST['receipt_id'] ?? 0);
        $stmt = $pdo->prepare('UPDATE lbm_client_receipts SET keep_forever = 1 WHERE receipt_id = ? AND (client_id = ? OR client_phone = ?)');
        $stmt->execute([$id, (int)$client['client_id'], $client['phone']]);
        json_response(['success' => true]);
    }
    json_response(['success' => false, 'message' => 'Unknown action'], 400);
} catch (Throwable $e) {
    json_response(['success' => false, 'message' => $e->getMessage()], 500);
}
