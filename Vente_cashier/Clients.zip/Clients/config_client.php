<?php
/**
 * Client-side helper config for LionTech Business Manager.
 * Put this folder in: C:\Xampp\htdocs\InventoryLiontech\Vente_cashier\Clients
 * It loads the main project Config.php located two folders up.
 */

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$rootConfig = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'Config.php';
if (file_exists($rootConfig)) {
    require_once $rootConfig;
}

function client_pdo(): PDO
{
    // Supports different possible names from your existing Config.php
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
        return $GLOBALS['pdo'];
    }
    if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof PDO) {
        return $GLOBALS['conn'];
    }
    if (function_exists('getPDO')) {
        $db = getPDO();
        if ($db instanceof PDO) return $db;
    }
    if (function_exists('getDB')) {
        $db = getDB();
        if ($db instanceof PDO) return $db;
    }
    if (function_exists('db')) {
        $db = db();
        if ($db instanceof PDO) return $db;
    }

    // Fallback for local XAMPP if Config.php does not expose a PDO variable.
    $host = 'localhost';
    $dbname = 'inventoryliontech';
    $user = 'root';
    $pass = '';
    $dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function h(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function current_client(): ?array
{
    if (empty($_SESSION['client_id'])) {
        return null;
    }
    $pdo = client_pdo();
    $stmt = $pdo->prepare('SELECT * FROM lbm_clients WHERE client_id = ? LIMIT 1');
    $stmt->execute([$_SESSION['client_id']]);
    $client = $stmt->fetch();
    return $client ?: null;
}

function require_client(): array
{
    $client = current_client();
    if (!$client) {
        header('Location: login.php');
        exit;
    }
    return $client;
}

function normalize_phone(string $phone): string
{
    $phone = trim($phone);
    $phone = preg_replace('/\s+/', '', $phone);
    return $phone ?: '';
}

function json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
