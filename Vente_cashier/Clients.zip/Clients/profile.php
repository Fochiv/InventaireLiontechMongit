<?php
require_once __DIR__ . '/config_client.php';
$client = require_client();
$qrData = json_encode([
    'type' => 'LBM_CLIENT',
    'client_id' => (int)$client['client_id'],
    'name' => $client['full_name'],
    'phone' => $client['phone'],
    'token' => $client['qr_token'],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$pageTitle = 'My QR';
include __DIR__ . '/partials/header.php';
?>
<main class="single-card-wrap">
    <section class="card qr-card">
        <a class="back-btn" href="dashboard.php">← <span data-i18n="back">Retour</span></a>
        <h1 data-i18n="my_client_qr">Mon QR client</h1>
        <p class="muted" data-i18n="qr_help">Le caissier peut scanner ce QR pour lier le reçu à votre compte.</p>
        <div id="qrBox" class="qr-box" data-qr='<?= h($qrData) ?>'></div>
        <h2><?= h($client['full_name']) ?></h2>
        <p class="muted"><?= h($client['phone']) ?></p>
    </section>
</main>
<script src="assets/js/qrcode.min.js"></script>
<?php include __DIR__ . '/partials/footer.php'; ?>
