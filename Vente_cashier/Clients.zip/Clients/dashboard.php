<?php
require_once __DIR__ . '/config_client.php';
$client = current_client();
$guestPhone = normalize_phone($_GET['phone'] ?? '');
$receipts = [];
$error = '';

try {
    $pdo = client_pdo();
    if ($client) {
        $stmt = $pdo->prepare('SELECT * FROM lbm_client_receipts WHERE client_id = ? OR client_phone = ? ORDER BY sale_datetime DESC, receipt_id DESC LIMIT 100');
        $stmt->execute([(int)$client['client_id'], $client['phone']]);
    } elseif ($guestPhone) {
        $stmt = $pdo->prepare('SELECT * FROM lbm_client_receipts WHERE client_phone = ? ORDER BY sale_datetime DESC, receipt_id DESC LIMIT 50');
        $stmt->execute([$guestPhone]);
    } else {
        header('Location: index.php');
        exit;
    }
    $receipts = $stmt->fetchAll();
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$displayName = $client['full_name'] ?? 'Client';
$displayPhone = $client['phone'] ?? $guestPhone;
$pageTitle = 'Receipts';
include __DIR__ . '/partials/header.php';
?>
<main class="dashboard-wrap">
    <section class="client-header card">
        <div>
            <p class="eyebrow" data-i18n="welcome">Bienvenue</p>
            <h1><?= h($displayName) ?></h1>
            <p class="muted"><?= h($displayPhone) ?></p>
        </div>
        <div class="header-actions">
            <?php if ($client): ?>
                <a class="btn ghost small" href="profile.php" data-i18n="my_qr">Mon QR</a>
                <a class="btn danger small" href="logout.php" data-i18n="logout">Déconnexion</a>
            <?php else: ?>
                <a class="btn soft small" href="register.php" data-i18n="save_forever">Créer un compte</a>
            <?php endif; ?>
        </div>
    </section>

    <section class="card tools-card">
        <div class="search-line">
            <input id="receiptSearch" type="search" placeholder="Rechercher par magasin, date, montant..." data-i18n-placeholder="search_receipts">
            <button class="btn soft" id="cacheReceipts" type="button" data-i18n="save_offline">Sauver hors ligne</button>
        </div>
        <div class="offline-note" id="offlineNote" data-i18n="offline_note">Les reçus ouverts sont gardés sur ce téléphone pour consultation hors ligne.</div>
    </section>

    <?php if ($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>

    <section class="receipt-grid" id="receiptGrid">
        <?php if (!$receipts): ?>
            <article class="card empty-state">
                <div class="big-icon">🧾</div>
                <h2 data-i18n="no_receipts">Aucun reçu trouvé</h2>
                <p class="muted" data-i18n="no_receipts_text">Quand un commerce utilise LBM, vos reçus apparaîtront ici.</p>
            </article>
        <?php endif; ?>

        <?php foreach ($receipts as $r): ?>
            <article class="receipt-card card" data-search="<?= h(strtolower(($r['business_name'] ?? '') . ' ' . ($r['invoice_no'] ?? '') . ' ' . ($r['total_amount'] ?? ''))) ?>">
                <div class="receipt-top">
                    <span class="store-icon">🏪</span>
                    <div>
                        <h3><?= h($r['business_name'] ?? 'Business') ?></h3>
                        <p><?= h($r['invoice_no'] ?? '') ?></p>
                    </div>
                </div>
                <div class="receipt-meta">
                    <span><?= h($r['sale_datetime'] ?? '') ?></span>
                    <strong><?= number_format((float)($r['total_amount'] ?? 0), 0, '.', ' ') ?> FCFA</strong>
                </div>
                <div class="receipt-actions">
                    <a class="btn primary small" href="receipt.php?id=<?= (int)$r['receipt_id'] ?>" data-i18n="view">Voir</a>
                    <?php if ($client): ?>
                        <button class="btn ghost small mark-important" data-id="<?= (int)$r['receipt_id'] ?>">⭐</button>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</main>
<script>
window.LBM_RECEIPTS = <?= json_encode($receipts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<?php include __DIR__ . '/partials/footer.php'; ?>
