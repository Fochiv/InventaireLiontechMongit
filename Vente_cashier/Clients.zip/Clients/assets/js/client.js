const CACHE_KEY = 'lbm_client_cached_receipts_v1';
function updateNetworkStatus(){
  const el = document.getElementById('networkStatus');
  if(!el) return;
  if(navigator.onLine){ el.textContent='● Online'; el.classList.remove('offline'); }
  else { el.textContent='● Hors ligne'; el.classList.add('offline'); }
}
window.addEventListener('online', updateNetworkStatus);
window.addEventListener('offline', updateNetworkStatus);
document.addEventListener('DOMContentLoaded', updateNetworkStatus);

function getCachedReceipts(){
  try { return JSON.parse(localStorage.getItem(CACHE_KEY) || '[]'); } catch { return []; }
}
function setCachedReceipts(data){ localStorage.setItem(CACHE_KEY, JSON.stringify(data || [])); }
function mergeReceipts(existing, incoming){
  const map = new Map();
  [...existing, ...incoming].forEach(r => map.set(String(r.receipt_id || r.invoice_no), r));
  return [...map.values()];
}

document.addEventListener('DOMContentLoaded',()=>{
  const search = document.getElementById('receiptSearch');
  if(search){
    search.addEventListener('input',()=>{
      const q = search.value.trim().toLowerCase();
      document.querySelectorAll('.receipt-card').forEach(card=>{
        card.style.display = card.dataset.search.includes(q) ? '' : 'none';
      });
    });
  }

  const cacheBtn = document.getElementById('cacheReceipts');
  if(cacheBtn){
    cacheBtn.addEventListener('click',()=>{
      const incoming = window.LBM_RECEIPTS || [];
      setCachedReceipts(mergeReceipts(getCachedReceipts(), incoming));
      cacheBtn.textContent = '✓ Sauvegardé';
      setTimeout(()=>cacheBtn.textContent = 'Sauver hors ligne', 1600);
    });
  }

  const saveReceipt = document.getElementById('saveReceiptOffline');
  if(saveReceipt){
    saveReceipt.addEventListener('click',()=>{
      const container = document.getElementById('receiptDetail');
      const payload = container?.dataset.receipt ? JSON.parse(container.dataset.receipt) : null;
      if(payload?.receipt){
        setCachedReceipts(mergeReceipts(getCachedReceipts(), [payload.receipt]));
        saveReceipt.textContent = '✓ Sauvegardé';
      }
    });
  }

  document.querySelectorAll('.mark-important').forEach(btn=>{
    btn.addEventListener('click', async()=>{
      const body = new FormData();
      body.append('receipt_id', btn.dataset.id);
      try{
        const res = await fetch('api/receipt_api.php?action=mark_important',{method:'POST',body});
        const json = await res.json();
        if(json.success) btn.textContent='⭐ Saved';
      }catch(e){ alert('Offline: action will need internet.'); }
    });
  });

  const qrBox = document.getElementById('qrBox');
  if(qrBox && window.QRCode){
    new QRCode(qrBox, { text: qrBox.dataset.qr || '', width: 200, height: 200, correctLevel: QRCode.CorrectLevel.M });
  }
});
