const LBM_I18N = {
  fr: {
    receipt_center:'Centre de reçus', hero_title:'Tous vos reçus au même endroit.', hero_text:'Entrez votre WhatsApp pour retrouver vos reçus, ou créez un compte pour garder un historique complet.', quick_access:'Accès rapide', quick_access_text:'Voir vos reçus avec votre numéro WhatsApp. Aucun mot de passe requis.', whatsapp_number:'Numéro WhatsApp', view_receipts:'Voir mes reçus', or:'ou', create_account:'Créer un compte', login:'Connexion', back:'Retour', account_benefit:'Gardez vos reçus, retrouvez-les plus tard et utilisez votre QR code client.', full_name:'Nom complet', password_pin:'Mot de passe / PIN', create_my_account:'Créer mon compte', login_text:'Connectez-vous pour voir votre historique complet.', welcome:'Bienvenue', my_qr:'Mon QR', logout:'Déconnexion', save_forever:'Créer un compte', save_offline:'Sauver hors ligne', offline_note:'Les reçus ouverts sont gardés sur ce téléphone pour consultation hors ligne.', no_receipts:'Aucun reçu trouvé', no_receipts_text:'Quand un commerce utilise LBM, vos reçus apparaîtront ici.', view:'Voir', my_client_qr:'Mon QR client', qr_help:'Le caissier peut scanner ce QR pour lier le reçu à votre compte.', date:'Date', cashier:'Caissier', payment:'Paiement', print:'Imprimer', search_receipts:'Rechercher par magasin, date, montant...'
  },
  en: {
    receipt_center:'Receipt center', hero_title:'All your receipts in one place.', hero_text:'Enter your WhatsApp number to find receipts, or create an account for a full history.', quick_access:'Quick access', quick_access_text:'View receipts with your WhatsApp number. No password required.', whatsapp_number:'WhatsApp number', view_receipts:'View my receipts', or:'or', create_account:'Create account', login:'Login', back:'Back', account_benefit:'Keep your receipts, find them later, and use your client QR code.', full_name:'Full name', password_pin:'Password / PIN', create_my_account:'Create my account', login_text:'Login to view your full history.', welcome:'Welcome', my_qr:'My QR', logout:'Logout', save_forever:'Create account', save_offline:'Save offline', offline_note:'Opened receipts are saved on this phone for offline viewing.', no_receipts:'No receipts found', no_receipts_text:'When a business uses LBM, your receipts will appear here.', view:'View', my_client_qr:'My client QR', qr_help:'The cashier can scan this QR to connect the receipt to your account.', date:'Date', cashier:'Cashier', payment:'Payment', print:'Print', search_receipts:'Search by store, date, amount...'
  }
};

function setLanguage(lang){
  localStorage.setItem('lbm_client_lang', lang);
  document.documentElement.lang = lang;
  document.documentElement.dataset.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.dataset.i18n;
    if(LBM_I18N[lang]?.[key]) el.textContent = LBM_I18N[lang][key];
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{
    const key = el.dataset.i18nPlaceholder;
    if(LBM_I18N[lang]?.[key]) el.placeholder = LBM_I18N[lang][key];
  });
  document.querySelectorAll('[data-set-lang]').forEach(btn=>btn.classList.toggle('active', btn.dataset.setLang===lang));
}

document.addEventListener('DOMContentLoaded',()=>{
  const saved = localStorage.getItem('lbm_client_lang') || 'fr';
  setLanguage(saved);
  document.querySelectorAll('[data-set-lang]').forEach(btn=>btn.addEventListener('click',()=>setLanguage(btn.dataset.setLang)));
});
