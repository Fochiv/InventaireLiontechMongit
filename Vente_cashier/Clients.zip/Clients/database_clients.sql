-- LionTech Business Manager - Client Receipts Module
-- Import this SQL in the same database used by InventoryLiontech.

CREATE TABLE IF NOT EXISTS `lbm_clients` (
  `client_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(35) NOT NULL,
  `password_hash` VARCHAR(255) DEFAULT NULL,
  `qr_token` VARCHAR(80) NOT NULL,
  `account_status` ENUM('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`),
  UNIQUE KEY `uq_lbm_clients_phone` (`phone`),
  UNIQUE KEY `uq_lbm_clients_qr` (`qr_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `lbm_client_receipts` (
  `receipt_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED DEFAULT NULL,
  `client_name` VARCHAR(120) DEFAULT NULL,
  `client_phone` VARCHAR(35) DEFAULT NULL,
  `business_id` INT UNSIGNED DEFAULT NULL,
  `business_name` VARCHAR(160) NOT NULL DEFAULT 'Business',
  `invoice_no` VARCHAR(50) NOT NULL,
  `sale_datetime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cashier_id` INT UNSIGNED DEFAULT NULL,
  `cashier_name` VARCHAR(120) DEFAULT NULL,
  `payment_method` VARCHAR(40) NOT NULL DEFAULT 'Cash',
  `payment_reference` VARCHAR(100) DEFAULT NULL,
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `tax_amount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `total_amount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `keep_forever` TINYINT(1) NOT NULL DEFAULT 0,
  `expires_at` DATETIME GENERATED ALWAYS AS (DATE_ADD(`sale_datetime`, INTERVAL 1 YEAR)) STORED,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`receipt_id`),
  UNIQUE KEY `uq_lbm_receipts_invoice` (`invoice_no`),
  KEY `idx_lbm_receipts_client` (`client_id`),
  KEY `idx_lbm_receipts_phone` (`client_phone`),
  KEY `idx_lbm_receipts_date` (`sale_datetime`),
  CONSTRAINT `fk_lbm_receipts_client` FOREIGN KEY (`client_id`) REFERENCES `lbm_clients` (`client_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `lbm_client_receipt_items` (
  `item_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `receipt_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED DEFAULT NULL,
  `product_name` VARCHAR(160) NOT NULL,
  `quantity` DECIMAL(12,3) NOT NULL DEFAULT 1,
  `unit_label` VARCHAR(20) NOT NULL DEFAULT 'unit',
  `unit_price` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `line_total` DECIMAL(12,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_id`),
  KEY `idx_lbm_receipt_items_receipt` (`receipt_id`),
  CONSTRAINT `fk_lbm_receipt_items_receipt` FOREIGN KEY (`receipt_id`) REFERENCES `lbm_client_receipts` (`receipt_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional demo data. Remove if not needed.
INSERT INTO `lbm_client_receipts` (`client_name`, `client_phone`, `business_name`, `invoice_no`, `sale_datetime`, `cashier_name`, `payment_method`, `subtotal`, `tax_amount`, `total_amount`)
VALUES ('Marie Test', '+237699000000', 'Carrefour Test', 'FAC-2026-0001', NOW(), 'Joy', 'Cash', 2200, 0, 2200)
ON DUPLICATE KEY UPDATE invoice_no = invoice_no;

INSERT INTO `lbm_client_receipt_items` (`receipt_id`, `product_name`, `quantity`, `unit_label`, `unit_price`, `line_total`)
SELECT r.receipt_id, 'Coca Cola', 3, 'unit', 500, 1500 FROM lbm_client_receipts r WHERE r.invoice_no = 'FAC-2026-0001'
ON DUPLICATE KEY UPDATE product_name = product_name;
