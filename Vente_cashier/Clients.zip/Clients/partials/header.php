<?php
if (!isset($pageTitle)) { $pageTitle = 'Client Receipts'; }
?>
<!doctype html>
<html lang="fr" data-lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#123C7C">
    <title><?= h($pageTitle) ?> | LionTech Business Manager</title>
    <link rel="manifest" href="manifest.webmanifest">
    <link rel="stylesheet" href="assets/css/client.css">
</head>
<body>
<div class="app-shell">
    <header class="topbar">
        <div class="brand-mini">
            <img src="../../Image/logo_lionTechhead.jpeg" alt="LionTech" onerror="this.style.display='none'">
            <div>
                <strong>LBM Client</strong>
                <span data-i18n="receipt_center">Centre de reçus</span>
            </div>
        </div>
        <div class="lang-switch" aria-label="Language switcher">
            <button type="button" data-set-lang="fr" class="active">FR</button>
            <button type="button" data-set-lang="en">EN</button>
        </div>
    </header>
