</div>
<script src="assets/js/i18n.js"></script>
<script src="assets/js/client.js"></script>
<script>
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js').catch(console.warn);
}
</script>
</body>
</html>
