<?php
require_once __DIR__ . '/config_client.php';
$id = (int)($_GET['id'] ?? 0);
$receipt = null;
$items = [];
$error = '';
try {
    $pdo = client_pdo();
    $stmt = $pdo->prepare('SELECT * FROM lbm_client_receipts WHERE receipt_id = ? LIMIT 1');
    $stmt->execute([$id]);
    $receipt = $stmt->fetch();
    if ($receipt) {
        $it = $pdo->prepare('SELECT * FROM lbm_client_receipt_items WHERE receipt_id = ? ORDER BY item_id ASC');
        $it->execute([$id]);
        $items = $it->fetchAll();
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}
$pageTitle = 'Receipt';
include __DIR__ . '/partials/header.php';
?>
<main class="single-card-wrap">
    <?php if (!$receipt): ?>
        <section class="card empty-state"><h1>Reçu introuvable</h1><p><?= h($error) ?></p><a class="btn primary" href="index.php">Accueil</a></section>
    <?php else: ?>
        <section class="card receipt-detail" id="receiptDetail" data-receipt='<?= h(json_encode(['receipt'=>$receipt,'items'=>$items], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>'>
            <a class="back-btn" href="dashboard.php">← <span data-i18n="back">Retour</span></a>
            <div class="receipt-brand">
                <img src="../../Image/logo_lionTechhead.jpeg" alt="logo" onerror="this.style.display='none'">
                <div>
                    <h1><?= h($receipt['business_name'] ?? 'Business') ?></h1>
                    <p><?= h($receipt['invoice_no'] ?? '') ?></p>
                </div>
            </div>
            <div class="detail-row"><span data-i18n="date">Date</span><strong><?= h($receipt['sale_datetime'] ?? '') ?></strong></div>
            <div class="detail-row"><span data-i18n="cashier">Caissier</span><strong><?= h($receipt['cashier_name'] ?? '-') ?></strong></div>
            <div class="detail-row"><span data-i18n="payment">Paiement</span><strong><?= h($receipt['payment_method'] ?? '-') ?></strong></div>

            <div class="items-list">
                <?php foreach ($items as $item): ?>
                    <div class="item-line">
                        <div>
                            <strong><?= h($item['product_name'] ?? '') ?></strong>
                            <span><?= h($item['quantity'] ?? '') ?> × <?= number_format((float)($item['unit_price'] ?? 0), 0, '.', ' ') ?> FCFA</span>
                        </div>
                        <strong><?= number_format((float)($item['line_total'] ?? 0), 0, '.', ' ') ?> FCFA</strong>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="totals-box">
                <div><span>Sous-total</span><strong><?= number_format((float)($receipt['subtotal'] ?? 0), 0, '.', ' ') ?> FCFA</strong></div>
                <div><span>TVA</span><strong><?= number_format((float)($receipt['tax_amount'] ?? 0), 0, '.', ' ') ?> FCFA</strong></div>
                <div class="grand"><span>Total TTC</span><strong><?= number_format((float)($receipt['total_amount'] ?? 0), 0, '.', ' ') ?> FCFA</strong></div>
            </div>

            <div class="grid-2 no-print">
                <button class="btn soft" type="button" onclick="window.print()" data-i18n="print">Imprimer</button>
                <button class="btn primary" type="button" id="saveReceiptOffline" data-i18n="save_offline">Sauver hors ligne</button>
            </div>
        </section>
    <?php endif; ?>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
